// Copyright 2002 Combex, Inc. under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html
//
// PrimChar16.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMCHAR16_H)
#define PRIMCHAR16_H


#include "Script.h"

extern Script *Char16Script;


#endif // !defined(PRIMCHAR16_H)
