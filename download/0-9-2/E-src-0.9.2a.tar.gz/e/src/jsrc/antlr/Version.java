package antlr;

public class Version {

    static public final String version = "2";
    static public final String subversion = "7";
    static public final String patchlevel = "5rc2";
    static public final String datestamp = "2005-01-08";
    static public final String project_version =
      "2.7.5rc2 (" + datestamp + ")";

    private Version() {
    }
}
