package antlr.debug;

public class MessageEvent extends Event {

    static private final long serialVersionUID = -4634645612449373388L;

    private String text;
    static public int WARNING = 0;
    static public int ERROR = 1;


    public MessageEvent(Object source) {
        super(source);
    }

    public MessageEvent(Object source, int type, String text) {
        super(source);
        setValues(type, text);
    }

    public String getText() {
        return text;
    }

    void setText(String text) {
        this.text = text;
    }

    /**
     * This should NOT be called from anyone other than ParserEventSupport!
     */
    void setValues(int type, String text) {
        super.setValues(type);
        setText(text);
    }

    public String toString() {
        return "ParserMessageEvent [" +
          (getType() == WARNING ? "warning," : "error,") + getText() + "]";
    }
}
