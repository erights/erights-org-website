package org.waterken.purchase_ajax;

public interface CreditBureau {

    void checkCredit(String name, Callback tellCreditOK);
}
