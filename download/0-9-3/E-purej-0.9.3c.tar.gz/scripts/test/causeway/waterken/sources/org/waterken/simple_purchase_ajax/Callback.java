package org.waterken.simple_purchase_ajax;

public interface Callback {

    public void run(boolean answer);
}
