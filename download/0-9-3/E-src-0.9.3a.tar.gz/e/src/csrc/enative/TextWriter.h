// Copyright 2002 Combex, Inc. under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html
//
// TextWriter.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(TEXTWRITER_H)
#define TEXTWRITER_H


#include "Script.h"

extern Ref EOut;
extern Ref EErr;


#endif // !defined(TEXTWRITER_H)
