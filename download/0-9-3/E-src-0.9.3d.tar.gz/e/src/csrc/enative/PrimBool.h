// Copyright 2002 Combex, Inc. under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html
//
// PrimBool.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMBOOL_H)
#define PRIMBOOL_H


#include "Script.h"

extern Script *BoolScript;


#endif // !defined(PRIMBOOL_H)
