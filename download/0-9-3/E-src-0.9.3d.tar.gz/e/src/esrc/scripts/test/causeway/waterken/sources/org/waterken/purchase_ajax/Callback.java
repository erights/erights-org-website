package org.waterken.purchase_ajax;

public interface Callback {

    public void run(boolean answer);
}
