package org.waterken.simple_purchase_ajax;

public interface CreditBureau {

    void checkCredit(String name, Callback tellCreditOK);
}
