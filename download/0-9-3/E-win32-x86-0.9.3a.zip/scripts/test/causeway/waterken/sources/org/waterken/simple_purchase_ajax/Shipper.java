package org.waterken.simple_purchase_ajax;

public interface Shipper {

    void canDeliver(String profile, Callback tellCanDeliver);
}
