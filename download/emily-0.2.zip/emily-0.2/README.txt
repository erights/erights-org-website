
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)


Using and Compiling Emily

by Marc Stiegler (marcs@skyhunter.com)


This version of Emily was implemented with OCaml 3.09 under Windows XP. It uses Microsoft Visual Studio C++ for the backend that compiles the output of ocamlopt into native code. It should work with other versions of OCaml, but this is the only configuration in which it has been tested. Recompilation of emilyopt for Linux systems is required.

The core emily executable is emilyopt.exe. Emilyopt verifies that the application does not use authority improperly (i.e., it verifies that every object in the app is born in confinement, with only those authorities explicitly handed to it as references). Once emilyopt has verified that the app is confined, it compiles and links (using ocamlopt). Currently Emily is focused on native-code compilation usage.

The procedure described here has not been used by anyone except the author, so it will probably not work for you, 
and your feedback will be appreciated, particularly if the feedback is in the form of a new draft of this
document :-) 

---- Basic compilation of an Emily program  -----

The format of the Emily compilation command is:

	emilyopt powerboxFolderPath applicationFolderPath outputExecutablePath
	
where the powerboxFolder and applicationFolder have the following contents:

 - powerboxFolderPath is the path to the powerbox folder. This folder must 
    contain the following files: 
  		- stdLib.txt contains a single line, the path to the ocaml standard lib
  		- safeStdLib.txt a single line, the path to the tamed headers for the
  			standard lib
  		- safePowerLib.txt a single line, the path to the folder of 
  			tamed headers for the powerbox
  		- powerbox.ml The "main" file for the powerbox
  		- libs.txt a single line listing all the modules and libraries needed
  			by the ocamlopt compiler to compile this program. 
  			When the ocamlopt compiler is invoked as the last step in the emilyopt 
  			compilation, the command line will put this list of paths first, 
  			followed by the list of paths to the confined
  			modules, followed by powerbox.ml
  		- any *.lib files from the windows C compilation environment that are 
  			needed by the ocamlopt compiler. These files are copied into the
  			the application folder from the powerbox folder for linking, quite
  			awkward but which seemed to be the only way to 
  			get them included in the link compiling with MSVS C++. In principle, 
  			the code for doing this copying should fail quietly on a Linux system, and
  			the compilation should proceed just fine, but this has not been tested.
  			The specific libs needed for MSVS C++ are:
  				AdvAPI32.Lib
				Kernel32.Lib
				libcmt.lib
				oldnames.lib
				Uuid.Lib
				WSock32.Lib
			These Windows libs are not included in the distribution, you will have to get 
			them from MSVS or the Windows SDK. As noted earlier, using Linux or Cygwin
			the emilyopt should silently ignore the failure to collect these libs into the
			compilation folder, but this has not been tested.  
			
  - applicationFolderPath is the path to the folder where the confined modules source code 
    (the actual application) reside. In addition
  	to the confined modules themselves, this folder must contain a file named
  	"compile.order". This file lists each .mli and .ml file in the
  	order in which it should be compiled. The compile.order file format is one file per line, 
  	the filename only, not the path, no embedded blanks.
  	The application folder must not contain any files that are neither
    .mli nor .ml nor .order files.  There is one .order file, the compile.order file.
	
  - outputExecutablePath is the path to the output executable file, 
    probably ending in ".exe" if compiling on Windows. Do not put this
  	output file in the application folder or the powerbox folder, it would probably 
  	be deleted during the post-link cleanup. 
  
  The ocaml compiler ocamlopt and doc generator ocamldoc must be part of the environment, i.e.,
  emilyopt invokes ocamlopt and ocamldoc by their names, not their paths.
  
---- Samples -----

A number of sample applications are included: the sash powerbox can be used to compile sashcp, sashls, and sashdeck. You will find batch files to compile each of these samples. To run the samples, see the explanation in the HP Tech Report "Emily: A High Performance Languages for Breach Resistant Software". The general idea is found in the executable sashcp:

	sashcp =inputFileName +outputFileName

in which the "=" says, "give the app a readonly file handle on this file", and the "+" says, "give the app an editable file handle on this file". The benchmark program sashdeck can be run as follows:

	sashdeck 4000 ^time

in which the number is the number of decks that should be created, and the number of times each 
deck should be shuffled. The "^time" tells the powerbox to grant a readonly authority to the system clock.


--- Compiling emilyopt ---- 

compiling emilyopt, like compiling an app, requires that MSVS libs are included in the working directory as described earlier. The "main" file is emilyopt.ml. Compile emilyopt using ocamlopt. If you are on Windows, with MSVS installed and the libraries present, the batch file "compileEmilyopt.bat" should do the compilation for you.