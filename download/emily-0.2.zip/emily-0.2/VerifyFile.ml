
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
open Str

let notVariableNameChar() = "[^a-zA-Z0-9_]"


let flattenText text = Str.global_replace (Str.regexp "[\r\n]") " " text 

let hasWord text word =		
	let unsafeWord = regexp (".*"^(notVariableNameChar()) ^ word 
		^ (notVariableNameChar())^".*") in
	string_match unsafeWord text 0
	
(* returns first word in list that is found. Returns "" if no word found*)
let rec firstWordFromList text words =
	match words with
	[] -> ""
	| nextWord :: tail ->
		if (hasWord text nextWord) then
			nextWord
		else firstWordFromList text tail
		

let hasBadWord text =
	let unsafeWords = [
		"stdin"; 
	    "stdout"; 
	    "stderr"; 
	    "print_char";
	    "print_string";
	    "print_int";
	    "print_float";
	    "print_endline"; 
	    "print_newline"; 
	    "prerr_char";
	    "prerr_string"; 
	    "prerr_int";
	    "prerr_float"; 
	    "prerr_endline"; 
	    "prerr_newline"; 
	    "read_line"; 
	    "read_int"; 
	    "read_float";
	    "open_out";
	    "open_out_bin";
	    "open_out_gen";
	    "open_in";
	    "open_in_bin";
	    "open_in_gen";
	    "at_exit";
	    "valid_float_lexem";
	    "unsafe_really_input";
	    "do_at_exit";
		"external";
		"exception"] in
	(* precede and succede with blanks so no edge conditions*)
	firstWordFromList (" "^text^" ") unsafeWords
	
let fileIsSafe file userOut =
	let text = if file.File.exists() then file.File.getText() else "" in
	let flatText = flattenText text in
	let badWordFound = hasBadWord flatText in
	let fileName = file.File.fullPath () in
	if (badWordFound = "") then
		let _ = userOut ("Verified " ^ fileName ^ "\n" ) in
		true
	else
		let _ = userOut ("Unsafe word in " ^ fileName ^ ": " 
			^ badWordFound ^ "\n" ) in
		false
		
let codeHtmlIsSafe text userOut =
	let flatText = flattenText text in 
	let sections = split (regexp "<span class=\"keyword\">let</span>") flatText in
	let mainSection = match sections with
		header :: firstLet :: tail -> firstLet
		| _ -> "messedup"
	in
	let rearStripped = replace_first (regexp "=.*") " " mainSection in
	let nbspSpaced = global_replace (regexp "&nbsp;") " " rearStripped in
	let atLeast1arg = string_match (regexp ".*[a-zA-Z_].*\\b.*[a-zA-Z_(].*")
	    nbspSpaced 0 in
	if atLeast1arg then 	
		let _= userOut ("verified: " ^ nbspSpaced) in 
		true
	else 
		let _= userOut ("possible static var: " ^ nbspSpaced) in
		false
		
let htmlFolderIsSafe folder userOut =
	let codeValExp = Str.regexp "code_VAL.*" in
	let codeFiles = List.filter  (fun next ->
		Str.string_match codeValExp (Filename.basename (next.File.fullPath())) 0)
		(folder.File.subFiles()) in
	List.for_all (fun next ->
		let _= userOut ("statics check for " ^ (Filename.basename (next.File.fullPath()))) in
		codeHtmlIsSafe (next.File.getText()) userOut)
		codeFiles	

let testAlgorithm userOut = 
	let test testtext expectedResult = 
		let result = hasBadWord testtext  in
		if (result = expectedResult) then
			print_string ("success with: " ^ testtext ^ "\n------\n")
		else 
			print_string ("failed with: " ^ testtext ^ "\n got|"^result^"|"
			^"\n----\n")
	in
	let _= test "abc" "" in
	let _= test "blah external blah" "external" in
	let _ = test "stdin blah" "stdin" in
	let _= test "stdinblah blah" "" in
	let _= test "stdinblah stderr" "stderr" in
	let _= test "abc\r\nprint_string def" "print_string" in
	let testhtml testtext expectedResult = 
		if (codeHtmlIsSafe testtext userOut = expectedResult) then
			print_endline "html test succeeded"
		else print_endline ("html failed: " ^ testtext)
	in
	let _ = testhtml "code class=\"code\"><span class=\"keyword\">let</span>&nbsp;pi&nbsp;=&nbsp;3.14</code></body></html>" 
		false in
	let _ = testhtml "code class=\"code\"><span class=\"keyword\">let</span>&nbsp;pi()&nbsp;=&nbsp;3.14</code></body></html>" 
		true in
	testhtml "<code class=\"code\"><span class=\"keyword\">let</span>&nbsp;next&nbsp;deck&nbsp;=&nbsp;&nbsp;<span"
		true
		

