
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
open SashInterface

type bot = {mutable location : int;
        mutable velocity : int;
        action : int -> int -> int -> int -> int}

(* Valid accelerations are -1, 0, 1. Force bot into one of these categories *)
let accelerate theBot accel =
    theBot.velocity <- theBot.velocity +
        (if accel = 0 then 0 else accel / (abs accel));
    theBot.location <- theBot.location + theBot.velocity

let composeMap arenaMaxLoc botA botB =
    let displayMap = Buffer.create (arenaMaxLoc + 1) in
    for i = 0 to arenaMaxLoc do
        Buffer.add_char displayMap
            (if (botA.location = i && botB.location = i) then 'X'
            else if (botA.location == i) then 'A'
            else if (botB.location == i) then 'B'
            else '-');
    done;
    Buffer.contents displayMap

let start userIn userOut auths =
    let indent = String.make 25 ' ' in
    let indentOut output = userOut (indent ^ output) in
    match auths with
    | Str arena :: Editable logA :: Editable logB :: []  ->
        let arenaMaxLoc = int_of_string arena in
        let hitArenaWall location = location < 0 || location > arenaMaxLoc in
        let botA = {location = 0; velocity = 0; action = BotA.make arenaMaxLoc logA} in
        let botB = {location = arenaMaxLoc; velocity = 0; action = BotB.make arenaMaxLoc logB} in
        let gameOver() = hitArenaWall(botA.location)
            || hitArenaWall(botB.location)
            || botA.location = botB.location in
        while (not (gameOver())) do
            indentOut "BotA moving...\n";
            let accA = botA.action botA.location botA.velocity
                botB.location botB.velocity in
            indentOut "BotB moving...\n";
            let accB = botB.action botB.location botB.velocity
                botA.location botA.velocity in
            accelerate botA accA;
            accelerate botB accB;
            indentOut ((composeMap arenaMaxLoc botA botB) ^
                "\n" ^ indent ^ "Bot A velocity = " ^ (string_of_int botA.velocity) ^
                ".     Bot B velocity = " ^ (string_of_int botB.velocity) ^ ".\n\n");
        done;
        if (hitArenaWall botA.location) then indentOut "A crashed and lost";
        if (hitArenaWall botB.location) then indentOut "B crashed and lost";
        if (botB.location = botA.location) then
            if (abs botA.velocity > abs botB.velocity) then
                indentOut "A crushed B"
            else if (abs botA.velocity < abs botB.velocity) then
                indentOut "B crushed A"
            else indentOut "A and B crushed each other";
        0
    | _ -> userOut "Need arena length, log file for bot A, log file for bot B";1

