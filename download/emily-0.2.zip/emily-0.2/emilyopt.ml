
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Usage: emilyopt powerboxFolderPath applicationFolderPath outputExecutablePath 
	where
	
  - powerboxFolderPath is the path to the powerbox folder. This folder must contain the following 
  	files: 
  		- stdLib.txt contains a single line, the path to the ocaml standard lib
  		- safeStdLib.txt a single line, the path to the tamed headers for the
  			standard lib
  		- safePowerLib.txt a single line, the path to the folder of 
  			tamed headers for the powerbox
  		- powerbox.ml The "main" file for the powerbox
  		- libs.txt a single line listing all the modules and libraries needed
  			by the ocamlopt compiler. When the compiler is invoked, the command line will
  			put this list of paths first, followed by the list of paths to the confined
  			modules, followed by powerbox.ml
  		- any *.lib files from the windows C compilation environment that are 
  			needed by the ocamlopt compiler. These files are copied into the
  			the application folder from the powerbox folder for linking, quite
  			awkward but which seemed to be the only way to 
  			get them included in the link compiling with MSVS C++. In principle, 
  			the code for doing this copying should fail quietly on a Linux system, and
  			the compilation should proceed just fine, but this has not been tested.
  			The specific libs needed for MSVS C++ seem to be:
  				AdvAPI32.Lib
				Kernel32.Lib
				libcmt.lib
				oldnames.lib
				Uuid.Lib
				WSock32.Lib
			But your mileage may vary.
			
  - applicationFolderPath is the path to the folder where the confined modules source code 
    (the actual application) reside. In addition
  	to the confined modules themselves, this folder must contain a file named
  	"compile.order". This file lists each .mli and .ml file in the
  	order in which it should be compiled. The compile.order file format is one file per line, 
  	the filename only, not the path, no embedded blanks.
  	The application folder must not contain any files that are neither
    .mli nor .ml nor .order files.  There is one .order file, the compile.order file.
	
  - outputExecutablePath is the path to the output executable file, 
    probably ending in ".exe" if compiling on Windows. Do not put this
  	output file in the application folder or the powerbox folder, it would probably 
  	be deleted during the post-link cleanup. 
  
  The ocaml compiler ocamlopt and doc generator ocamldoc must be part of the environment, i.e.,
  emilyopt invokes ocamlopt and ocamldoc by their names, not their paths.
  
  *)
 
 
let powerboxFolder = SysFile.make (Sys.argv.(1)) File.ReadOnly in
let appFolder = SysFile.make (Sys.argv.(2)) File.Editable in
let exeOut = SysFile.make (Sys.argv.(3)) File.Editable in

let getSysFileFromTextFile filename = 
	let textfile = powerboxFolder.File.subFile filename in
	let pathToFile = textfile.File.getText() in
	SysFile.make(pathToFile) File.ReadOnly 
in
	
let safePowerFolder = getSysFileFromTextFile "safePowerLib.txt" in
let safeStdFolder = getSysFileFromTextFile "safeStdLib.txt" in
let stdFolder = getSysFileFromTextFile "stdLib.txt" in
let libsForCompile = (powerboxFolder.File.subFile "libs.txt").File.getText() in
let powerboxPath = Filename.concat (powerboxFolder.File.fullPath()) "powerbox.ml" in

let staticsDocGenPath = Filename.concat (Sys.getcwd()) "staticsDocVerifier.cmo" in

let _= print_endline "got args" in

let validSuffix filename = (Filename.check_suffix filename ".mli" 
	|| Filename.check_suffix filename ".ml"
	|| Filename.check_suffix filename ".order") in

let killInvalidAppFiles () =
	(*kill any invalid files in the folder*)
	List.map (fun next ->
		if not (validSuffix (next.File.fullPath())) then
			next.File.delete())
		(appFolder.File.subFiles())
in
		
let _= killInvalidAppFiles() in
		
let appFiles = appFolder.File.subFiles() in
let appFilePaths = List.map (fun next -> next.File.fullPath()) appFiles in
let appFileNames = List.map (fun next -> Filename.basename next) appFilePaths in
(*let _= List.map (fun next -> print_endline next) appFileNames in*)

	
(*make sure all invalid files are dead, in case some survived the
	earlier attempt to kill them all*)
let allFileExtensionsSafe = List.for_all (fun next -> validSuffix next) 
	appFileNames in
let _= if not allFileExtensionsSafe then
	let _= print_endline "has at least one file without extension ml, mli, or order" in
	exit 2
in

(* make sure the unsafe files do not have names that override the names of the 
	unsafe modules either unsafe stdlib or unsafe powerbox lib *)
let unsafeNames = List.map (fun next -> 
	String.lowercase (Filename.basename (next.File.fullPath())))
	(powerboxFolder.File.subFiles() @ (stdFolder.File.subFiles())) in
let allFilenamesSafe = List.for_all (fun next -> 
	let result = not (List.mem (String.lowercase next) unsafeNames) in
	let _= if not result then 
		print_endline ("bad: " ^ next)in
	result) 
	appFileNames in
let _=if not allFilenamesSafe then 
	let _= print_endline "a program module file name is the same as a library filename. Abort." in
	exit 2
in

(* make sure no funny stuff in the confined list of files in compile.order, i.e., 
  no quotes or slashes that might enable inclusion of unacceptable files*)
let orderText = (appFolder.File.subFile("compile.order")).File.getText() in
let namesInOrderWithBlanks = Str.split (Str.regexp "[^a-zA-Z0-1_.]") orderText in
let namesInOrder = List.filter (fun next -> String.length next > 0) 
	namesInOrderWithBlanks in
let userOut text = print_endline text in

let _= List.map (fun next -> print_endline next) namesInOrder in

(* make sure no functions from pervasives, or the keyword "external", is used in
   the confined sources *)
  
let noBadWords = List.for_all (fun next -> VerifyFile.fileIsSafe 
	(appFolder.File.subFile(next)) userOut) namesInOrder in
let _= if not noBadWords then
	let _= print_endline "unsafe function calls or keywords" in
	exit 2
in


let enquote text = " \"" ^ text ^ "\" " in

(* switch to confined dir to ensure no power accidentally included 
   because of implicit inclusion from current dir *)
   
let _= Sys.chdir (appFolder.File.fullPath()) in
let _= print_endline ("working dir: " ^ Sys.getcwd()) in

(* compile against the safe std and power libs*)

let prolog = "ocamlopt -nostdlib -c " in
let includeSafePowerFolder = " -I " ^ (enquote (safePowerFolder.File.fullPath())) in
let includeSafeLib = " -I " ^ (enquote (safeStdFolder.File.fullPath())) in
let filesToCompile = String.concat " " 	namesInOrder in
let commandline = prolog ^ includeSafePowerFolder 
	^ includeSafeLib ^ filesToCompile in
let _= print_endline commandline in
let compileErr = Sys.command commandline in	 
let _= if compileErr <> 0 then 
	let _= print_endline "library compile failed" in
	exit 2
in

let _= print_endline "\nCompilation against safe lib completed\n" in

(* ensure there are no static mutables by running ocamldoc with 
	a static mutables detector *)

	
let htmlFolder = (appFolder.File.subFile "html") in
let _= if htmlFolder.File.exists() then
	htmlFolder.File.delete() in
let _= htmlFolder.File.mkDir() in

let mlFilePaths = List.filter (fun next -> Filename.check_suffix  next ".ml" )
	appFileNames in
let fileListForStaticCheck = String.concat " " mlFilePaths  in

let staticsProlog = "ocamldoc -no-stop " in
let docGenPath = " -g " ^ (enquote (staticsDocGenPath)) in

let staticsCommand = staticsProlog 
	^ docGenPath
	^ includeSafePowerFolder
	^ includeSafeLib 
	^ fileListForStaticCheck in
let _= print_endline ("statics command: " ^ staticsCommand) in
let staticsErr = Sys.command staticsCommand in
let _= if staticsErr <> 0 then
	let _= print_endline "statics analysis failed" in
	exit 2 
in

let _= print_endline "\n\nNow linking\n" in

(* finally, compile and link against full power libs *)
let copyLibsCommand = "copy " ^ (enquote ((powerboxFolder.File.fullPath()) ^ "\\*.lib"))
	^ (enquote(appFolder.File.fullPath())) in
let _= print_endline copyLibsCommand in
let _= Sys.command copyLibsCommand in

let includeAppFolder = " -I " ^ (enquote (appFolder.File.fullPath())) in
let includeUnsafeLib = " -I " ^ (enquote(powerboxFolder.File.fullPath() )) in
let linkProlog = "ocamlopt " in
let linkOut = " -o " ^ (enquote (exeOut.File.fullPath()  )) in
let linkCommand = linkProlog ^ linkOut ^ includeAppFolder ^ includeUnsafeLib 
	^ libsForCompile ^ " " ^ filesToCompile ^ " "
	^ (enquote powerboxPath) in
let _= print_endline linkCommand in
let linkErr = Sys.command linkCommand in
let _= if linkErr <> 0  then
	let _= print_endline "Link failed" in
	exit 2 in

let _= killInvalidAppFiles() in

print_endline "\n\nSafe Executable Created";;
