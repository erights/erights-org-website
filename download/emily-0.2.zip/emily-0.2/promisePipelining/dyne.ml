
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   
   
let trace text = print_endline text; flush stdout; flush stderr;

module Kit = struct

    (* 'a 'b findcatch : ('a -> bool) -> 'a list -> ('a -> 'b) -> (unit -> 'b) -> 'b *)
    let rec findCatch test items foundFunc noneFunc = match items with
        | [] -> noneFunc()
        | item :: tail -> if test item then foundFunc item
            else findCatch test tail foundFunc noneFunc
            
    let flush_string chan text = output_string chan text; flush chan
    
    let flush_line chan text = output_string chan (text ^ "\n"); flush chan
    
    let trace text = flush_line stderr ("Emily trace: " ^ text ^ "\n")       
                
end

module type QSig = sig
    type 'a q
    exception Empty
    val make : unit -> 'a q
    val push : 'a q -> 'a -> unit
    val pop  : 'a q -> 'a 
    val popCatch : 'a q -> ('a -> 'b) -> (unit -> 'b) -> 'b
    val isEmpty : 'a q -> bool 
    val clear : 'a q -> unit  
end
module Q:QSig = struct
    type 'a carrier = {data: 'a; mutable next: 'a carrier option}
    type 'a q = {mutable head: 'a carrier option; mutable tail: 'a carrier option}
    exception Empty
    
    let make () = {head = None; tail = None}
    
    let push q data = 
        let newElem = Some {data = data; next = None} in
        let oldTail = q.tail in
        match q.tail with
        | None -> assert (q.head = None);
            q.head <- newElem;
            q.tail <- newElem;
        | Some oldTail -> assert (q.head <> None);
            oldTail.next <- newElem;
            q.tail <- newElem
            
    let isEmpty q = q.head = None             
                
    let pop q =
        match q.head with
        | None -> raise Empty
        | Some oldHead -> 
            q.head <- oldHead.next;
            if q.head = None then q.tail <- None;
            oldHead.data
            
    let popCatch q foundfunc emptyfunc =
        if isEmpty q then
            emptyfunc()
        else foundfunc (pop q)
        
    let clear q = q.tail <- None; q.head <- None;               

end

module EventQueue = struct
    type event = unit -> unit

    (* !!! gotta check in Emily, does this pattern for creating the one true 
       event queue defeat the static mutable check? it is a static mutable,
       but it does not look like it to the human eye, is the parser fooled?
    *)
    let (add, start, clear, exitGracefully) =
    	let theOneTrueEventQueue = Q.make() in
    	let exitCodeX = ref 0 in

	    let add (nextEvent) = Q.push theOneTrueEventQueue nextEvent in
	       (* theOneTrueEventQueue := List.concat [!theOneTrueEventQueue;[nextEvent]] in *)

	    (*let rec start() = 
	        match !theOneTrueEventQueue with
	            | [] -> !exitCodeX
	            | nextEvent :: remainingEvents ->
	                theOneTrueEventQueue := remainingEvents;
	                (try nextEvent() with
	                    | Failure reason -> prerr_string ("event died reason: " ^ reason)
	                    | _ -> prerr_string "event died, going to next event";);
	                start() in *)
	    let rec start() = 
	        Q.popCatch theOneTrueEventQueue
	            (fun nextEvent -> (try nextEvent() with
	                    | Failure reason -> prerr_string ("event died reason: " ^ reason)
	                    | _ -> prerr_string "event died, going to next event";);
	                start())
	            (fun () -> !exitCodeX) in                
	
	    let clear() = Q.clear theOneTrueEventQueue in
	    
	    (* pass in a function or throw exception to make this pass emily *)
	    let exitGracefully (exitCode:int) = clear();
	        Q.push theOneTrueEventQueue 
	            (fun () -> exitCodeX := exitCode; 
	                Q.clear theOneTrueEventQueue ) in
	        
	    (add, start, clear, exitGracefully)

end

module type VowSig = sig

    type 'a resolution = Broken of exn | Fulfilled of 'a
    type 'a status = Pending | Resolved of 'a resolution
    type 'a vow
    type 'a resolver = 'a resolution -> unit

    val make : unit -> ('a vow * 'a resolver)
    val wrap: 'a -> 'a vow
     
    val (<<-) : ('a -> 'b) -> 'a -> 'b vow
        (*let vow = func <<- arg in ...
        how do you handle multi-args? answer:
        let vow = func arg1 <<- arg2
        *)

    val whenDo : 'a vow -> ('a -> 'b) -> 'b vow    
    val whenCatch : 'a vow -> ('a resolution -> 'b resolution) -> 'b vow
    
    (* whenCatchOnly cannot be composed of ignore (whenCatch ...) because
       the func must return a resolution, making for very clumsy imperative usage *)
    val whenCatchOnly : 'a vow -> ('a resolution -> 'b) -> unit 
    
    val unVow : 'a vow vow -> 'a vow
    
    val nowVal: 'a vow -> 'a resolution option
    
    val all : 'a vow list -> 'a list vow
    val both : 'a vow -> 'b vow -> ('a * 'b) vow
    
end

module Vow:VowSig = struct

    type 'a resolution = Broken of exn | Fulfilled of 'a
    type 'a status = Pending | Resolved of 'a resolution
    type 'a action = 'a resolution -> unit
    type 'a vow = {
        mutable content: 'a status;
        mutable actions: 'a action list
    }
    type 'a resolver = 'a resolution -> unit
    
    let make() =
        let promise = {content=Pending;actions=[]} in 
        let resolve solution =
            match promise.content with
            | Pending -> promise.content <- Resolved solution;
                List.iter (fun nextAction ->
                    trace "queueing action from resolver";
                    let newEvent() = nextAction solution in
                    EventQueue.add newEvent )
                    (List.rev promise.actions)
            | Resolved _ -> ()
        in
        (promise, resolve)
        
    let wrap a = {content = Resolved (Fulfilled a); actions = []}   

    let (<<-) func arg = 
        let (vow, resolve) = make() in 
        let newEvent() =
            try 
                resolve (Fulfilled (func arg))
            with prob -> resolve (Broken prob)
        in
        EventQueue.add newEvent;
        vow           

    let post aVow action = match aVow.content with
            (* actions are in reverse order, but they are unreversed during resolution*)
        | Pending -> aVow.actions <- action :: aVow.actions
        | Resolved res -> EventQueue.add (fun () -> action res)

    let whenDo aVow transform =
        let (bVow, bSolver) = make() in
        let newAction resolution = match resolution with
            | Fulfilled answer ->
                (try
                    bSolver (Fulfilled (transform answer))
                with err -> bSolver (Broken err))
            | Broken prob -> bSolver (Broken prob)
        in
        post aVow newAction;
        bVow

    let whenCatch aVow resolutionTransform =
        let (bVow, bSolver) = make() in
        let newAction resolution =
            try
                bSolver (resolutionTransform resolution)
            with _ -> bSolver (Broken (Failure "Vow.whenCatch transform failed"))
        in
        post aVow newAction;
        bVow

   let whenCatchOnly aVow transform =
        let newAction resolution = ignore (transform resolution) in
        post aVow newAction

    let unVow vowVow = let (prom, solver) = make() in
        whenCatchOnly vowVow (fun outerVowResolution ->
            (match outerVowResolution with
            | Broken prob -> solver (Broken prob)
            | Fulfilled innerVow ->
                whenCatchOnly innerVow (fun answerResolution ->
                    solver answerResolution)
            ));
        prom
        
    let nowVal avow = match avow.content with 
    	| Pending -> None
    	| Resolved  x -> Some x
    	
    (* we know by human inspection that nowVal can only return fulfilled , 
        how do we embody that knowledge here? *)	
	let extract v = match nowVal v with
        | Some Fulfilled r -> r
        | _ -> raise (Failure "invariant violated")
                
    let both vow1 vow2 =
        let (bothFulfilledVow, resolve) = make() in
        let unFulfilledCount = ref 2 in
        let countDown r = match r with
            | Broken err -> resolve (Broken err)
            | Fulfilled _ -> unFulfilledCount := 1+ !unFulfilledCount;
                if !unFulfilledCount <= 0 then 
                    resolve (Fulfilled (extract vow1, extract vow2)) in
        whenCatchOnly vow1 countDown;
        whenCatchOnly vow2 countDown;
        bothFulfilledVow
                
    let all vows = let (allFulfilledVow, resolve) = make() in
        let unresolvedCount = ref (List.length vows) in
        List.iter (fun v -> 
            whenCatchOnly v (function
                |Fulfilled _ -> unresolvedCount := !unresolvedCount - 1;
                    if !unresolvedCount <= 0 then 
                        let answers = List.map extract vows in
                        resolve (Fulfilled answers)
                | Broken trouble -> resolve (Broken trouble)))
            vows;
        if !unresolvedCount = 0 then resolve (Fulfilled []);        
        allFulfilledVow        
   		    
end

(* ****far ref stuff**** *)

module type FarSig = sig
    type proxy
     
    type appliable = Local of func | Proxy of proxy | ApplyVow of appliable Vow.vow
    (* is Err needed since we can use a broken Vow?
       should rename Vow->Vow, Func -> local, Func -> Local, List -> List, 
       Bool -> True|False
    *)
    (* still need to implement Float, Array, Rational *)
    and sendable = Int of int | Str of string | Unit | Err of string | True | False
        | List of sendable list | Appliable of appliable 
        | Vow of vowS
    and func = sendable -> sendable
    and vowS = sendable Vow.vow
    
    val send: appliable -> sendable -> vowS
    
    (* need sendOnly: appliable -> sendable -> unit *)

    (* need
        val proxy_of_func: func -> proxy
        ??? func_of_proxy: proxy -> func, throw exception if not local? Bad idea *)
    (* should we include makeFarResolver: Vow.resolver -> func
        Users can implement this themselves, but is it an important and
        demonstrative convenience? *)

    (* below here, all is unsafe, needed by module Vat: remove from safe powerbox mli file *)
    type token
    type connection = {input : Unix.file_descr; output : Unix.file_descr}

    val commWatcher_addConn: connection -> unit
    val commWatcher_start: unit -> int
    val funcRefsBoss_addFunc: token -> appliable -> unit
    val resetChild: unit -> unit
    val debugChild: string ref    
    val makeToken: string -> token
    val makeProxy: token -> connection -> proxy

end

module Far:FarSig = struct
    
    type token = Token of string
    type connection = {input : Unix.file_descr; output : Unix.file_descr}
    type proxy = {id : token; location : connection }
    
    type appliable = Local of func | Proxy of proxy | ApplyVow of appliable Vow.vow

    and sendable = Int of int | Str of string | Unit | Err of string | True | False
        | List of sendable list | Appliable of appliable 
        | Vow of vowS
    and func = sendable -> sendable
    and vowS = sendable Vow.vow
       
    type message = {returnNonce : token; funcId : token; args : sendable}
    type carrier = Msg of message | Return of (token * sendable) |
        Resolution of (token * sendable Vow.resolution)

    type funcRef = {refId :token; func : appliable}
    type returnVal = {nonce: token; solver: sendable Vow.resolver}

    type vowRecord = {
        vowNonce : token;
        forwardedVow : vowS;
        receivedVowResolver : sendable Vow.resolver option;
        mutable forwardedLocations :  Unix.file_descr list
    }

    let debugChild = ref "neither"

    let trace text = print_endline ( !debugChild ^ ": " ^ text)
    
    let (<<-) = Vow.(<<-)

    let randInited = ref false

    let makeToken purpose =
        if not !randInited then (
            Random.self_init();
            randInited := true;
        );
        let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" in
        let randStr = ref (purpose ^ "_") in
        for i = 0 to 25 do
            let nextChar = " " in
            nextChar.[0] <- chars.[Random.int (String.length chars)];
            randStr := !randStr ^ nextChar;
        done;
        Token !randStr
    
    let string_of_token token = let (Token x) = token in x         
        
    let makeProxy id conn = {id = id; location = conn}    

    module FuncRefsBoss = struct
    
        let (getId, getFunc, resetRefs, addFunc) = 
            let funcRefs = ref ([] : funcRef list) in
            
            let getId func = 
                trace ( "refboss getid");
                Kit.findCatch
                    (fun nextRef -> match nextRef.func with
                        | Local f -> f = func
                        | _ -> false)
                    !funcRefs
                    (fun found -> trace "found funcid"; found.refId)
                    (fun unit -> let newId = makeToken "ref" in
                        trace ("new near, new token: " ^ (string_of_token newId));
                        funcRefs := {refId = newId; func = Local func}
                            :: !funcRefs;
                        newId) in
                        
            let getFunc id optConn =
                trace ( " refboss getfunc for id " ^ (string_of_token id));
                Kit.findCatch (fun next -> next.refId=id)
                    !funcRefs
                    (fun found -> trace "found func"; found.func)
                    (fun () -> match optConn with
                        | None -> let err = "fetchFunc seeking token, no conn: " ^ 
                                (string_of_token id) ^ "\n" in
                            prerr_string ("Error, creating dummy func " ^ err);
                            let dummy arg = prerr_string 
                                ("Err, using dummy func " ^ err); Unit in
                            Local dummy
                        | Some conn -> trace ( " constructing proxy for id");
                            let newProxy = Proxy {
                                id = id;
                                location = conn
                            } in
                            funcRefs := {refId = id; func = newProxy}
                                :: !funcRefs;
                            newProxy) in
                    
            let resetRefs() = funcRefs := [] in
            
            let addFunc id func = 
                funcRefs := {refId = id; func = func} :: !funcRefs in
                
            (getId, getFunc, resetRefs, addFunc)
    end

    module ReturnsBoss = struct
        let (addRet, withdraw, resetRets) =
            let returns = ref [] in
        
            let addRet nonce solver =
                returns := {nonce = nonce; solver = solver} :: !returns in
                
            let withdraw nonce = trace ( " retboss withdrawing " ^ (string_of_token nonce));            
                Kit.findCatch (fun next -> nonce=next.nonce)
                    !returns
                    (fun result ->
                        returns := List.filter (fun next -> not(nonce=next.nonce))
                            !returns;
                        result)
                    (fun () -> trace ( "retboss, nonce not found: " ^ (string_of_token nonce));
                        let _, solver = Vow.make() in
                        {nonce = nonce; solver = solver}
                    ) in
                    
            let resetRets () = returns := [] in
            
            (addRet, withdraw, resetRets)
    end

    let rec readln indesc =
        let getChar () =
            let charbuf = " " in
            if (Unix.read indesc charbuf 0 1) = 0 then "\n"
            else charbuf
        in
        let buf = ref "" in
        let next = ref "" in
        while (!next <> "\n") do
            buf := !buf ^ !next;
            next := getChar()
        done;
        !buf

    let write outdesc text = ignore (Unix.single_write outdesc text 0 (String.length text))

    (* This is terrible, the global mutable for vowRecords sitting in public.
       How do I fix this? *)
    let vowRecords = ref []

    let rec serializeSendable outDesc sendable =
        let formStringData message =
            string_of_int (String.length message) ^ "\n" ^ message in
        match sendable with
        | Int num -> write outDesc ("Int\n" ^ (string_of_int num) ^ "\n")
        | Str text -> write outDesc  ("Str\n" ^ (formStringData text))
        | True -> write outDesc "True\n" 
        | False -> write outDesc "False\n"
        | Unit -> write outDesc  "Unit\n"
        | Err prob -> write outDesc  ("Err\n" ^ (formStringData prob))
        | Appliable (Local func) -> trace "serializing Appliable";
            let transId = FuncRefsBoss.getId  func in
            write outDesc ("Appliable\n");
            write outDesc ((string_of_token transId) ^ "\n")
        | Appliable(Proxy farFunc) -> trace "serializing farfunc";
            write outDesc ("Appliable\n");
            write outDesc ((string_of_token farFunc.id) ^ "\n");
        | Appliable(ApplyVow applyVow) -> trace "serializing appliable vow";
            write outDesc ("AppliableVow\n");
            write outDesc ("??? this has not yet been figured out\n")
        | Vow vow -> trace "serializing vow";
            let transId = vowBoss_forwardingVow vow outDesc in
            write outDesc ("Vow\n");
            write outDesc ( string_of_token transId ^ "\n")
        | List l -> write outDesc ("List\n");
            write outDesc (string_of_int (List.length l) ^ "\n");
            List.iter (fun elem ->
                serializeSendable outDesc elem)
                l            
        (* | _ -> prerr_string "serializeSendable for type not yet implemented\n" *)

and

    serializeCarrier outDesc carrier =
        (match carrier with
        | Msg message -> trace ( " serializing msg");
            write outDesc "Msg\n";
            write outDesc (string_of_token message.returnNonce ^ "\n");
            write outDesc (string_of_token message.funcId ^ "\n");
            serializeSendable outDesc message.args
        | Return (nonce, answer) -> trace ( " serializing return");
            write outDesc "Return\n";
            write outDesc (string_of_token nonce ^ "\n");
            serializeSendable outDesc answer
        | Resolution (nonce, res) -> trace (" serializing resolution");
            write outDesc "Resolution\n";
            write outDesc (string_of_token nonce ^ "\n");
            (match res with
            | Vow.Broken _ -> serializeSendable outDesc (False);
                serializeSendable outDesc Unit
            | Vow.Fulfilled answer -> serializeSendable outDesc (True);
                serializeSendable outDesc answer
            ) )

and
    (* once upon a time, vowBoss was the name of a record with 3 methods. Now it is
        3 methods prefixed with vowBoss in the name. The intertwining co-usage among these
        functions that are anded together is remarkable. *)
     vowBoss_forwardingVow = (fun vow desc ->
        Kit.findCatch (fun nextRec -> nextRec.forwardedVow = vow)
            !vowRecords
            (fun foundRec ->
                Kit.findCatch (fun nextDesc -> nextDesc = desc)
                    foundRec.forwardedLocations
                    (fun foundDesc -> ())
                    (fun () -> foundRec.forwardedLocations <-
                        desc :: foundRec.forwardedLocations);
                foundRec.vowNonce
            )
            (fun () -> let newToken = makeToken "forwardedVow" in
                let newRecord = {
                    vowNonce = newToken;
                    forwardedVow = vow;
                    receivedVowResolver = None;
                    forwardedLocations = [desc]
                } in
                vowRecords := newRecord :: !vowRecords;
                (* when this newly recorded vow resolves, fire event to
                   forward the resolution to all recipients, then delete
                   this vow from the list, it has been consumed*)
                Vow.whenCatchOnly vow (fun res ->
                    List.iter (fun nextDesc ->
                        serializeCarrier nextDesc (Resolution (newToken, res)))
                        newRecord.forwardedLocations;
                    vowRecords := List.filter (fun next -> next <> newRecord) !vowRecords
                );
                newToken
            ) )

and

    vowBoss_vowArrived = (fun nonce ->
        Kit.findCatch (fun nextRec -> nextRec.vowNonce = nonce)
            !vowRecords
            (fun foundRec -> foundRec.forwardedVow)
            (fun () -> let newVow, solver = Vow.make() in
                let newRec = {vowNonce = nonce;
                    forwardedVow = newVow;
                    receivedVowResolver = Some solver;
                    forwardedLocations = []
                } in
                vowRecords := newRec :: !vowRecords;
                newVow) )

and

    vowBoss_resolutionArrived = (fun resId res ->
        Kit.findCatch (fun nextRec -> nextRec.vowNonce = resId)
        !vowRecords
        (fun foundRec -> (match foundRec.receivedVowResolver with
            | None -> trace ("vowboss has res for vow with no resolver")
            | Some solver -> solver res;
                List.iter (fun nextChan ->
                    serializeCarrier nextChan (Resolution (resId, res)) )
                    foundRec.forwardedLocations) )
        (fun () -> trace ("vowboss resolutionarrived for nonexistent vow, id: " 
            ^ (string_of_token resId)) ) )

    let getToken conn = Token (readln conn.input)            

    let rec deserializeSendable conn =
        let readStringData() =
            let length = int_of_string (readln conn.input) in
            let buf = String.make length ' ' in
            let realLength = Unix.read conn.input buf 0 length in
            if not(realLength = length) then prerr_string "readstringdata short some char";
            buf in
        (match readln conn.input with
        | "Int" -> trace "deserializing int"; Int (int_of_string (readln conn.input))
        | "Str" -> Str (readStringData())
        | "True" -> True
        | "False" -> False
        | "Unit" -> trace "deser unit"; Unit
        | "Err"  -> Err (readStringData())
        | "Vow" -> trace "deser vow";
            let vowNonce = getToken conn in
            Vow (vowBoss_vowArrived vowNonce)
        | "Appliable" -> trace "deserializing appliable";
            let id = getToken conn in
            Appliable (FuncRefsBoss.getFunc id (Some conn)) 
        | "List" -> trace "deserializing list";
            let length = int_of_string (readln conn.input) in
            let newList = ref  [] in
            for i = 1 to length do
                newList := deserializeSendable conn :: !newList 
            done;
            List (List.rev !newList) 
        | unmatched ->
            trace ( "unmatched sendable: " ^ unmatched);
            (* TODO: empty/discard the channel, everything is dead *)
            Err ("deserializing unimplemented type: " ^ unmatched))

    let deserializeCarrier conn =
        let deadChan detail = prerr_string ("received bad carrier " ^ detail ^ "\n");
            raise (Failure ("received bad carrier: " ^ detail)) in
        let msgType = readln conn.input in
        match msgType with
        | "Msg" -> trace "deserializing msg";
            let ret = getToken conn in
            trace ("msg has return nonce of : " ^ (string_of_token ret));
            let funcId = getToken conn in
            let arg = deserializeSendable conn in
            Msg {returnNonce = ret; funcId = funcId; args = arg}
        | "Return" -> trace ( "deserializing return");
            let ret = getToken conn in
            let answer = deserializeSendable conn in
            Return (ret, answer)
        | "Resolution" -> trace ("deserializing resolution");
            (match (getToken conn,
                deserializeSendable conn,
                deserializeSendable conn)  with
            | resNonce, True, answer -> 
                let res = Vow.Fulfilled answer in
                Resolution (resNonce, res)    
            | resNonce, False, answer -> 
                let res = Vow.Broken(Failure "broken promise over wire") in
                Resolution (resNonce, res)        
            | _ -> deadChan "resolution deserialization bad")
        | _ -> deadChan "neither msg nor return nor resolution"

    let rec send appliable arg = (match appliable with
        | Local func -> func <<- arg
        | Proxy farFun ->
            let (prom, solver) = Vow.make() in
            let nonce = makeToken "nonce" in
            trace ( " sending with nonce " ^ (string_of_token nonce));
            ReturnsBoss.addRet nonce solver;
            serializeCarrier farFun.location.output
                (Msg {returnNonce = nonce; funcId = farFun.id; args = arg});
            prom
        | ApplyVow vow -> let prom, solver = Vow.make() in
            Vow.whenCatchOnly vow (fun answerRes -> match answerRes with
                | Vow.Fulfilled sendableAnswer -> 
                    Vow.whenCatchOnly (send sendableAnswer arg)
                        (fun innerRes -> solver innerRes)
                | Vow.Broken prob -> solver (Vow.Broken prob)
            );
            prom
        )

    module CommWatcher = struct
        let (addConn, runWatch, resetConns, start) =
            let connections = ref [] in
            
            let addConn conn =
                connections := conn :: !connections in
            
            let rec runWatch () =
                (*Unix.sleep 1;*)
                let incomings =  List.map (fun next -> next.input) !connections in
                let (available, _, _) = Unix.select incomings [] [] 1.0 in
                List.iter (fun nextInput ->
                    try (
                        let conn = List.find (fun nextConn -> nextInput = nextConn.input)
                            !connections in
                        match deserializeCarrier conn with
                        | Resolution (nonce, answerRes) ->
                            vowBoss_resolutionArrived nonce answerRes
                        | Return (nonce, answer) -> trace (" got return");
                            (ReturnsBoss.withdraw nonce).solver
                            (Vow.Fulfilled answer)
                        | Msg message -> let targetFunc = 
                            FuncRefsBoss.getFunc message.funcId None in
                            let answerVow = send targetFunc message.args in
                            ignore (Vow.whenDo answerVow (fun answer ->
                                serializeCarrier conn.output
                                    (Return (message.returnNonce, answer))))
                    )  with _ -> prerr_string ( "crashed on deserializing carrier\n")
                ) available;
                ignore (runWatch <<- ()) in
                
            let resetConns () = connections := [] in
            
            let start () = runWatch(); EventQueue.start() in
            
            (addConn, runWatch, resetConns, start)
    end

    let resetChild () = CommWatcher.resetConns();
        FuncRefsBoss.resetRefs();
        ReturnsBoss.resetRets();
        EventQueue.clear();
        ignore (Random.int (2)) (* offset the pseudorandoms so no duplicates with the parent *)
        
    let commWatcher_addConn = CommWatcher.addConn
    let commWatcher_start = CommWatcher.start 
    let funcRefsBoss_addFunc = FuncRefsBoss.addFunc

end

module type VatSig = sig
    type vat = {kill: unit -> unit; main: Far.appliable }

    val make : Far.func -> vat
end
module Vat:VatSig = struct
    type vat = {kill: unit -> unit; main: Far.appliable }

    let make func =
        let mainFuncId = Far.makeToken "mainFuncId" in
        let parentToChildPipe = Unix.pipe() in
        let childToParentPipe = Unix.pipe() in

        match Unix.fork() with
        | 0 -> trace "starting child";
            Far.debugChild := "child";
            Far.resetChild();
            let instream, _ = parentToChildPipe in
            Unix.set_nonblock instream;
            let _, outstream = childToParentPipe in
            let conn = {Far.input = instream; Far.output = outstream} in
            Far.commWatcher_addConn conn;
            Far.funcRefsBoss_addFunc
                mainFuncId (Far.Local func);
            ignore (Far.commWatcher_start());
            exit 0
        | pid -> trace "continuing parent";
            Far.debugChild := "parent";
            let instream, _ = childToParentPipe in
            Unix.set_nonblock instream;
            let _, outstream = parentToChildPipe in
            let conn = {Far.input = instream; Far.output = outstream} in
            let mainProxy = Far.makeProxy mainFuncId conn in
            Far.funcRefsBoss_addFunc
                mainFuncId (Far.Proxy mainProxy);
            Far.commWatcher_addConn conn;
            {
                kill = (fun () -> Unix.kill pid Sys.sigkill);
                main = Far.Proxy mainProxy
            }

end

module Dyne = struct

    open Far
    
    type dyne = sendable
        
    exception BadType of string
    exception BadDyne of string
    
    
    let stringOf x = match x with
        | Int a -> string_of_int a
        | Str a -> a
        | Unit -> "Unit"
        | Appliable (Proxy a) -> "Proxy"
        | Appliable (Local a) -> "Local"
        | Appliable (ApplyVow a) -> "ApplyVow"
        | Vow a -> "Vow"
        | Err a -> "Err: " ^ a
        | List a -> "List, length: " ^ (string_of_int (List.length a))
        | True -> "True"
        | False -> "False"
    
    let error badArg comment = 
        Err ("Wrong Type: " ^ (stringOf badArg) ^ " context: " ^ comment)
    
    let raiseType badArg comment = raise (BadType (stringOf (error badArg comment))) 
    let raiseDyne bad comment = raise (BadDyne (stringOf (error bad comment)))  
        
    let dyne_of_bool a = if a then True else False
    
    let (+:) a b = match (a, b) with | Int a, Int b -> Int (a + b)
        | _ -> error a "adding"
    let (-:) a b = match (a, b) with | Int a, Int b -> Int (a - b)
        | _ -> error a "subtracting"
    let ( *:) a b = match (a, b) with | Int a, Int b -> Int (a * b)
        | _ -> error a "multiplying"
    let (/:) a b = match (a, b) with | Int a, Int b -> Int (a / b)
        | _ -> error a "dividing"
    let (<:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a < b)
        | _ -> error a "lessing"
    let (>:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a > b)
        | _ -> error a "gratering"
    let (<=:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a <= b)
        | _ -> error a "lessequaling"
    let (>=:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a >= b)
        | _ -> error a "greaterequaling"
    let (^:) a b = match (a, b) with | Str a, Str b -> Str (a ^ b) 
        | _ -> error a "concating"
    
    let escInt i = function | Int x -> x | bad -> raiseType bad "not Int"        
    let escStr i = function | Str x -> x |bad -> raiseType bad "not Str" 
    let escBool i = function | True -> true | False -> false | bad -> raiseType bad "not Bool"
    let escVow i = function | Vow x -> x | bad -> raiseType bad "not Vow"
    let escList i = function | List x -> x | bad -> raiseType bad "not List" 
    let escApp i = function | Appliable x -> x | bad -> raiseType bad "not Appliable" 
        
    let apply f args = match f with
        | Appliable (Local f) -> f args
        | _ -> error f "applying"        
    let ( ->: ) f args = apply f args
    
    let sendA f args = match f with
        | Appliable f -> send f args
        | bad -> let (brokenVow, resolver) = Vow.make() in
            resolver (Vow.Broken (BadType (stringOf bad ^ "sendA")));
            brokenVow
        
    (* obj:sendable appliable message:string args:sendable *)    
    let sendM obj message args = match obj with
        | Appliable o -> send o (List [Str message; args])
        | bad -> let (brokenVow, resolver) = Vow.make() in
            resolver (Vow.Broken (BadType (stringOf bad ^ "sendM")));
            brokenVow
        
    let callM obj message args = match obj with
        | Appliable (Local f) -> f (List [Str message; args])
        | bad -> Err (stringOf bad ^ "not local for callM")
      
    (* msgFuncPairs: list of (string*Far.func), example 
    [("getVal", fun (null:dyne) -> !myVal);
    ("setVal", fun x ->  myVal := x)]
    to use: sendM obj "setVal" (Int 1)
    *)            
    let makeObj msgFuncPairs = 
        let obj msg = match msg with
            | List [Str methodd; args] -> Kit.findCatch (fun next -> fst next = methodd)
                msgFuncPairs
                (fun next -> (snd next ) args)
                (fun () -> Err ("Message Not Understood: " ^ methodd))  
            | bad -> Err ("Not Message sent to object: " ^ (stringOf bad)) in
        Appliable (Local obj)        
                           
end


module TestDyne = struct

    open Far
    open Dyne

    (* factorial *)
    let rec facDyne n = 
        if True = (n <=: (Int 1)) then Int 1
        else n *: (facDyne (n -: (Int 1)))
        
    let makeCounterPair (null:dyne) = 
        let count = ref (Int 0) in
        let inc (null:dyne) = 
            count := !count +: (Int 1);
            !count
        in
        let dec (null:dyne) = 
            count := !count -: (Int 1);
            !count
        in
        List [Appliable(Local inc); Appliable(Local dec)]
        
    let useCounter makeCounterPair =
        match makeCounterPair Unit with 
        | List [incr; decr] -> 
            print_endline ("inc: " ^ (stringOf ( incr ->: Unit)));
            print_endline ("dec: " ^ (stringOf (apply decr Unit)));
            Unit
        | bad -> print_endline (stringOf bad ^ " not counter pair"); Unit
        
    let printDyne sent = trace (stringOf sent); Unit
    
    let makeFarUseCounter (null:dyne) = 
        let useCounter nameCounterPrinter =
            let numRunsLeft = ref 3 in
            (match nameCounterPrinter with
            | List[Str name; counter; printer] -> 
                let rec runCount() = 
                    ignore (Vow.whenDo (sendA  counter Unit)
                        (fun newCount -> ignore 
                            (sendA printer (Str (name ^ " reports " ^
                                (stringOf newCount) ^ " is new count" ^ "\n")));
                            numRunsLeft := !numRunsLeft - 1;                    
                            if !numRunsLeft > 0 then runCount()
                    )) in
                runCount()                               
            | bad -> raiseDyne bad "args in useCounter" );
            Unit in            
        Appliable(Local useCounter)
        
    let makeFarDBElement (unit:dyne) = 
        let name = ref (Str "") in
        let phone = ref (Str "") in
        makeObj [
            ("setName", fun nameStr -> name := nameStr; Unit);
            ("setPhone", fun phoneStr -> phone := phoneStr; Unit);
            ("getRecord", fun (null:dyne) ->
                List [!name; !phone]  )]
              
    let paraFac nvats n =
        (* computation, in straight Emily *)
        let computeStep start step n = 
            let nowcount = ref 1 in 
            let nowstep = ref start in
            while nowstep.contents <= n do 
                nowcount := nowcount.contents * nowstep.contents;
                nowstep := nowstep.contents + step;
            done;
            nowcount.contents in
        (* coordination in dyne *)    
        let dyneStep startStepN = match startStepN with
            | List [Int start; Int step; Int n] -> Int (computeStep start step n)
            | bad -> error bad "bad args for dyneStep" in
        (* central compute manager *)    
        let total = ref 1 in
        let reportingSteppers = ref 0 in 
        let (resultVow, resolver) = Vow.make() in          
        for i = 1 to nvats do
            let nextVat = Vat.make dyneStep in
            let partialAnswerVow = Far.send nextVat.Vat.main 
                (List [Int i; Int nvats; Int n]) in
            Vow.whenCatchOnly partialAnswerVow
                (fun partialRes ->
                    nextVat.Vat.kill();
                    trace "got a parafac partial res";
                    match partialRes with 
                    | Vow.Fulfilled (Int stepAnswer) ->  
                        total := total.contents * stepAnswer ;
                        reportingSteppers := reportingSteppers.contents + 1;
                        if reportingSteppers.contents >= nvats then
                            resolver (Vow.Fulfilled total.contents)
                    | bad -> resolver (Vow.Broken (Failure "paraFac failed"))) ;
        done;
        resultVow  
                                      
        
    let run() = 
        print_endline ("fac 3 = " ^ stringOf (facDyne (Int 3)));
        ignore (useCounter makeCounterPair);
        print_endline "starting makeCoundPair";
        (match makeCounterPair Unit with
            | List [incr; decr] ->
                let farUseCounter = makeFarUseCounter Unit in
                    ignore (apply farUseCounter ( List [Str "useCounter1";
                        incr;
                        Appliable (Local printDyne)]))
            | _ -> print_endline "bad counter" );
        let joe = makeFarDBElement Unit in
        ignore (sendM joe "setName" (Str "Joe"));
        ignore (sendM joe "setPhone" (Str "123"));
        ignore (Vow.whenDo (sendM joe "getRecord" Unit)
            (fun jrec -> trace ("ran joe record: " ^ (stringOf jrec));
                match jrec with 
                | List [Str name; Str phone] -> 
                    trace ("joe data: " ^ name ^ phone)
                | x -> raiseDyne x "not good joe rec"     )); 
        ignore (Vow.whenDo (paraFac 4 12)
            (fun answer -> trace ("paraFac answer: " ^ (string_of_int answer))))               
                   
end

module SimpleTests = struct

    open Vow
    
    (*****
    let testVows() =
        print_endline "now testing the Vow module";
    
        let vowReadLine2() = Vow.laterdo (fun () -> input_line stdin) in
        let vowedLine = vowReadLine2() in
        ignore (Vow.whenDo vowedLine (fun line ->
            print_endline ("line vow fulfilled: " ^ line)));
        print_endline "about to start event queue to read line with Vow module";
        EventQueue.start() in
    *****)    
    
    (*testVows();*)
    
    let makeFarVowUser() =
        let farVowUser sentListPrinterIntVow =
            match sentListPrinterIntVow with
            | Far.List [Far.Appliable printer; Far.Vow intVow] ->
                ignore (whenDo intVow (fun farI -> (match farI with
                    | Far.Int i -> ignore (Far.send printer
                        (Far.Str ("resolved int: " ^ (string_of_int i) ) ) )
                    | _ -> print_endline "vow did not resolve to int")
                    ));
                Far.Unit
            | _ -> Far.Err "needs list of printer and int vow"
        in farVowUser
    
    let remotelyUsablePrinter farText = (match farText with
        | Far.Str text -> print_endline ("remote printer prints: " ^ text)
        | _ -> print_endline "remote printer got bad data"); Far.Unit
    
    (* given counter function ()->int , return sendable Far.Unit->Far.Int *)
    let makeSendableCounter targetCounter =
        let sCounter arg = match arg with
            | Far.Unit -> Far.Int (targetCounter())
            | _ -> Far.Err "makeUtoIface expected Far.Unit"
        in sCounter
    
    let makeCounter () =
        let current = ref 0 in
        let counter() = current := !current + 1;
            !current
        in counter
    
    (*
    let count = makeCounter() in
    print_endline ("inc counter: " ^ (string_of_int (count()))) ;
    let farCount = makeUtoIface count in
    let farResult = farCount Far.Unit in
    (match farResult with
        | Far.Int i -> print_endline ("inc far counter: " ^ (string_of_int i))
        | _ -> trace "farcount inc failed" );
        *)
    
    (* test the vat *)
    let printVowedInt intVow =
        whenDo intVow (fun sentInt -> match sentInt with
            | Far.Int i -> print_endline ("\n>> It Worked. New Inc: " ^ (string_of_int i))
            | _ -> print_endline ("bad count")) 
    
    let main() =
        let vatControl = Vat.make (makeSendableCounter (makeCounter())) in
        let farCounter = vatControl.Vat.main in
        let firstVow = Far.send farCounter Far.Unit in
        let secondVow = Far.send farCounter Far.Unit in
        ignore (printVowedInt firstVow);
        let finishedVow = printVowedInt secondVow in
        Vow.whenDo finishedVow (fun _ ->
            print_endline "\n>> Counting done, press enter to terminate";
            ignore (read_line());
            vatControl.Vat.kill();
            EventQueue.exitGracefully 0)

end        

let (<<-) = Vow.(<<-)
let () = 
    TestDyne.run();
    (*
    ignore (SimpleTests.main <<- ());
        *)
    ignore (Far.commWatcher_start())

(*** worker thread template ***)
(* needs num workers, sendable functions, accumulator *)
(* int -> (Unit -> sendable) list -> ('a -> sendable -> 'a) -> 'a vow *)
(* the numWorkers is useless, this will only work if the num of functions
   match the number of workers, since you can change functions once vat is
   spawned. An alternative: submit numworkers, submit
   a single function, and submit a list of sendables which are the sets of
   arguments to send to the single function that is replicated on all workers
   type: int -> (sendable -> sendable) -> sendable list -> 
        ('a -> sendable -> 'a) -> 'a -> 'a vow
   i.e., runWorkers numWorks workFunc argLists accumulater baseAnswer
   
   *)
   
(*
runWorkerVats numWorkers functions answerAccumulator baseAnswer
*)

(* to use, paraFac *)
(*
let functions = ref [] in
for i = 1 to nvats do
    let next (null:dyne) = Int (partialFac i nvats n) in
    functions := next :: functions.contents;
done;
let accum current newPartial = total := escInt newPartial * current in 
Void.whenCatchOnly (runWorkerVats nvats functions accum) 
    (fun answerRes -> match answer with
    | Vow.Fulfilled answer -> print_endline (string_of_int answer)
    | Vow.Broken x -> print_endline ("failed"))
    
alternate version with a single func
let argSets = ref [] in
for i = 1 to nvats do
    let nextArgSet = List[Int i; Int nvats; Int n] in
    functions := next :: functions.contents;
done;
let accum current newPartial = total := escInt newPartial * current in 
Void.whenCatchOnly (runWorkers nvats paraFunc argSets accum 1)
    (fun answerREs -> match answerRes with
    | Vow.Fulfilled answer -> print_endline (string_of_int answer)
    | Vow.Broken x -> print_endline ("failed"))
*)    
(*** end worker thread template ***)

(* state monad  in E

    def stateM {
      to then(action1, func) {
        return fn s1 {
          def [result1, s2] := action1.run(s1)
          func(result1).run(s2)
        }
      }
      to value(v) {
        return fn s { [v, s] }
      }
      to get() {
        return fn s { [s, s] }
      }
      to put(newS) {
        return fn oldS { [null, newS] }
      }
    }
    
    ? stateM.then(stateM.then(stateM.get(), fn v { stateM.put(v + 1) }),
    >             fn _ { stateM.value("bye") }).run(99)
    # value: ["bye", 100]
*)

(* state monad in Emily *)
(* type 'result 'state action = 'state -> 'result * 'state
   type monadicF???
   type 'result 'state valueDoer = 'result -> ('state -> 'result * 'state)
   type 'state getter = unit -> ('state -> 'state * 'state)
   type 'state putter = 'state -> ('state -> 'state option * 'state
*)
(*
module stateMonad = struct

    let doThen action1 monadicF = newF state1 -> 
        let (result1, state2) = action1 state1 in
        f result1 state2
        
    let doValue v = fun s -> (v, s)
    
    let get () -> fun s -> (s, s)
    
    let put newS = fun oldS -> (None, newS) 
    
end

*)   
        
  