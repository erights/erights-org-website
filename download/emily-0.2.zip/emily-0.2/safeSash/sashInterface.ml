
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   

type sashArg = Readable of MleFile.readable 
	| Editable of MleFile.editable
	| Time of (unit->float) 
	| Stdout of out_channel
	| Str of string