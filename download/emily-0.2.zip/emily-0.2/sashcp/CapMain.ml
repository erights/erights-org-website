
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   

(****** CapMain for cp readablefile editablefile ************)

open SashInterface  
let start userIn userOut authlist = 
	match authlist with 
	| Readable fromFile :: Editable outFile :: []  -> 
		outFile.MleFile.setBytes(fromFile.MleFile.getBytes()); 0
	| _ -> userOut "To use cp, an input file and output file are required"; 1
   
	