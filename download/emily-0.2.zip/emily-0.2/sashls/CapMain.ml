
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   

(****** CapMain for ls =folder ***)

let start userIn userOut authlist = 
	match authlist with
	| SashInterface.Readable dir :: [] -> 
		let lines = List.map (fun nextFile ->
			"    " ^ Filename.basename (nextFile.MleFile.fullPath()) ^ "\n"
		) (dir.MleFile.subRdFiles()) in
		userOut ("Contents of dir: \n" ^ (String.concat "" lines)); 0
	| _ -> userOut "To use ls, a folder is required"; 1

