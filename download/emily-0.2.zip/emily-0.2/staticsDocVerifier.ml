
(* Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
open Odoc_info
open Odoc_info.Value
open Odoc_info.Module
open Odoc_info.Type
open Odoc_info.Exception
open Odoc_info.Class


class gen () =
  object (self)
    inherit Odoc_info.Scan.scanner

									 
    method scan_value v =
    	let _= if not (is_function v) then 
    		let _= print_endline ("Possible static mutable: " ^ v.val_name) in
    		exit 2 in
    		()	
      	(*print_endline ("Verified " ^ (v.val_name))*)

(*
    method scan_type t =
      self#gen_if_tag
	t.ty_name
	(Odoc_html.Naming.complete_type_target t)
	t.ty_info

    method scan_exception e =
      self#gen_if_tag
	e.ex_name
	(Odoc_html.Naming.complete_exception_target e)
	e.ex_info

    method scan_attribute a =
      self#gen_if_tag
	a.att_value.val_name
	(Odoc_html.Naming.complete_attribute_target a)
	a.att_value.val_info

    method scan_method m =
      self#gen_if_tag
	m.met_value.val_name
	(Odoc_html.Naming.complete_method_target m)
	m.met_value.val_info;
*)

    method scan_included_module _ = ()
    
(*
    method scan_class_pre c =
      self#gen_if_tag
	c.cl_name
	(fst (Odoc_html.Naming.html_files c.cl_name))
	c.cl_info;
      true

    method scan_class_type_pre ct =
      self#gen_if_tag
	ct.clt_name
	(fst (Odoc_html.Naming.html_files ct.clt_name))
	ct.clt_info;
      true

    method scan_module_pre m =
      self#gen_if_tag
	m.m_name
	(fst (Odoc_html.Naming.html_files m.m_name))
	m.m_info;
      true

    method scan_module_type_pre mt =
      self#gen_if_tag
	mt.mt_name
	(fst (Odoc_html.Naming.html_files mt.mt_name))
	mt.mt_info;
      true
*)

    method scan_module_elements m =
      List.iter 
        (fun ele -> 
          match ele with
            Odoc_module.Element_module m -> 
	      self#scan_module m
          | Odoc_module.Element_module_type mt -> ()
          | Odoc_module.Element_included_module im -> self#scan_included_module im
          | Odoc_module.Element_class c -> ()
          | Odoc_module.Element_class_type ct ->()
          | Odoc_module.Element_value v -> self#scan_value v
          | Odoc_module.Element_exception e -> ()
          | Odoc_module.Element_type t -> ()
          | Odoc_module.Element_module_comment t -> ()
        )
        (Odoc_module.module_elements m)

    method scan_module_list l =
      let f m =
	self#scan_module m
      in
      List.iter f l

    method generate modules =
      self#scan_module_list modules;
      print_endline "Check for static mutables complete"
  end

class foo = object end

let generator = ((new gen ()) :> Odoc_args.doc_generator)

let _ = Odoc_args.set_doc_generator (Some generator)
