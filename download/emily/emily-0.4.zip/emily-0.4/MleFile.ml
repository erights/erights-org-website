(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

type readable = {	 
	 isDir : unit -> bool;
	 exists : unit -> bool;
	 subRdFiles : unit ->  readable list;
	 subRdFile : string -> readable;
	 inChannel : unit -> in_channel;
	 getBytes : unit -> string;
	 fullPath : unit -> string;
}

type editable = {
     ro : readable;
     subEdFiles : unit -> editable list;
     subEdFile : string -> editable;
	 outChannel : unit -> out_channel;
	 setBytes : string -> unit;
	 mkDir : unit -> unit;
	 createNewFile : unit -> unit;
	 delete : unit -> unit;
}




