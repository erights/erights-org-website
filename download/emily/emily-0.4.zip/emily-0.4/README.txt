
(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)


Using and Compiling Emily

by Marc Stiegler (marcs@skyhunter.com)

OCaml compatibilities and incompatibilities:

This version of Emily was implemented with OCaml 3.08 under cygwin under Windows XP. It is derived from a version of Emily created with OCaml 3.09 using Microsoft Visual Studio C++ for the backend. It is most certain, then, that this release of Emily will work with Cygwin. Second most certain is that the parts of this distribution that do not use concurrency (i.e., the emily verifier/compiler itself, and the applications using the sash powerbox)will work with 3.09 using MSVS. It is certain that the concurrency-aware parts of this distribution (applications using pipeSash) will not work with MSVS as the backend. Meanwhile, this version of Emily should work with other versions of OCaml, but the difficulties are unknown. Recompilation of emilyopt (the verifier/compiler) for Linux systems is required.

Overview of Emily Verifier/Compiler

The core emily executable is emilyopt.exe. Emilyopt verifies that the application does not use authority improperly (i.e., it verifies that every object in the app is born in confinement, with only those authorities explicitly handed to it as references). Once emilyopt has verified that the app is confined, it compiles and links (using ocamlopt). Currently Emily is focused on native-code compilation usage.

The procedure described here has only been used on 2 machines, so it will probably not work for you until you have struggled with it some; consequently your feedback will be appreciated, particularly if the feedback is in the form of a new draft of this document :-) Before starting, make sure that ocamlopt is working for you. An important item under cygwin is, make sure to set the environment variable with the path to the ocaml cygwin lib, i.e., "OCAMLLIB='c:\cygwin\lib\ocaml'".

---- Basic compilation of an Emily program  -----

The format of an Emily compilation command is:

	emilyopt powerboxFolderPath applicationFolderPath outputExecutablePath
	
where the powerboxFolder and applicationFolder have the following contents:

 - powerboxFolderPath is the path to the powerbox folder. This folder must 
    contain the following files: 
  		- stdLib.txt contains a single line (no terminating newline!), the path to the ocaml standard lib
  		- safeStdLib.txt a single line, the path to the tamed headers for the
  			standard lib
  		- safePowerLib.txt a single line(no terminating newline!), the path to the folder of 
  			tamed headers for the powerbox
  		- powerbox.ml The "main" file for the powerbox
  		- libs.txt a single line(no terminating newline!) listing all the modules and libraries needed
  			by the ocamlopt compiler to compile this program. 
  			When the ocamlopt compiler is invoked as the last step in the emilyopt 
  			compilation, the command line will put this list of paths first, 
  			followed by the list of paths to the confined
  			modules, followed by powerbox.ml
  		- any *.lib files from the windows C compilation environment that are 
  			needed by the ocamlopt compiler.  When using Cygwin, no such files
			are needed. When using MSVS C++ for the backend, they are.
			These files are copied into the
  			the application folder from the powerbox folder for linking, quite
  			awkward but which seemed to be the only way to 
  			get them included in the link compiling with MSVS C++. 
  			The specific libs needed for MSVS C++ are:
  				AdvAPI32.Lib
				Kernel32.Lib
				libcmt.lib
				oldnames.lib
				Uuid.Lib
				WSock32.Lib
			These Windows libs are not included in the distribution, you will have to get 
			them from MSVS or the Windows SDK. Using Cygwin is the recommended approach. 
			
  - applicationFolderPath is the path to the folder where the confined modules source code 
    (the actual application) reside. In addition
  	to the confined modules themselves, this folder must contain a file named
  	"compile.order". This file lists each .mli and .ml file in the
  	order in which it should be compiled. The compile.order file format is one file per line, 
  	the filename only, not the path, no embedded blanks.
  	The application folder must not contain any files that are neither
    .mli nor .ml nor .order files.  There is one .order file, the compile.order file.
	
  - outputExecutablePath is the path to the output executable file, 
    probably ending in ".exe" if compiling on Windows. Do not put this
  	output file in the application folder or the powerbox folder, it would probably 
  	be deleted during the post-link cleanup. 
  
  The ocaml compiler ocamlopt and doc generator ocamldoc must be part of the environment, i.e.,
  emilyopt invokes ocamlopt and ocamldoc by their names, not their paths.
  
---- Samples -----

A number of sample applications are included, using 2 powerboxes: the sash powerbox and the pipeSash powerbox. The sash powerbox is the simplest, and can be used to compiler dircp, sashls, and sashdeck. The pipeSash powerbox has been enhanced to enable concurrency that exploits multicore processors, using promise pipelining as the concurrency paradigm. This powerbox is used to compile sashcp (which does not exploit concurrency) and pipetest (which does exploit concurrency, including a parallel factorial computation)

You will find batch files to compile each of these samples. To run the samples, see the explanation in the HP Tech Report "Emily: A High Performance Languages for Breach Resistant Software". The general idea is found in the executable sashcp:

	sashcp =inputFileName +outputFileName

in which the "=" says, "give the app a readonly file handle on this file", and the "+" says, "give the app an editable file handle on this file". The benchmark program sashdeck can be run as follows:

	sashdeck 4000 ^time

in which the number is the number of decks that should be created, and the number of times each 
deck should be shuffled. The "^time" tells the powerbox to grant a readonly authority to the system clock.


--- Compiling emilyopt ---- 

Under Cygwin, the ocamlopt command line found in "compileEmilyopt.bat" should just do the compilation. If you use MSVS as the backend, compiling emilyopt, like compiling an app, requires that MSVS libs are included in the working directory as described earlier. The batch file "compileEmilyopt.bat" should do the compilation for you. 
