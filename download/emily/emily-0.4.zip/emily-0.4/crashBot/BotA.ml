(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

let make arenaMaxLoc logFile =
    fun myLoc myVel enemyLoc enemyVel ->
        if myLoc = 0 then 1
        else if myLoc = arenaMaxLoc then -1
        else 0

