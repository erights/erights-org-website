(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

(****** CapMain for cp readablefile editablefile ************)

open SashInterface 

let shortName dirpath filepath = 
    let namelength = String.length filepath - (String.length dirpath) in
    String.sub filepath (String.length filepath - namelength) namelength  

let copyFile userOut infile outfile =
    (*userOut ("copying: " ^ (infile.MleFile.fullPath()));*)
    if (not (outfile.MleFile.ro.MleFile.exists())) then outfile.MleFile.createNewFile();
    let inchan = infile.MleFile.inChannel() in
    let outchan = outfile.MleFile.outChannel() in
    let bufSize = 10000 in
    let buf = String.create bufSize in
    let bytesGotten = ref (input inchan buf 0 bufSize) in
    while !bytesGotten > 0 do
        output outchan buf 0 !bytesGotten;
        bytesGotten := input inchan buf 0 bufSize;
        (* userOut ("got: " ^ (string_of_int !bytesGotten));*)
    done;    
    close_out outchan;
    let inchanOnoutfile = outfile.MleFile.ro.MleFile.inChannel() in
    if (in_channel_length inchan <> (in_channel_length inchanOnoutfile)) then
        userOut ("length mismatch " ^ (infile.MleFile.fullPath()))
    else ();
    close_in inchan;
    close_in inchanOnoutfile
       
let rec copyFileObj userOut infile outfile =
    if (not(infile.MleFile.isDir())) then
        try  
            copyFile userOut infile outfile
        with prob -> userOut ("failed on: " ^ (infile.MleFile.fullPath()))
    else (
        let indir = infile in
        let outdir = outfile in
        if (not(outdir.MleFile.ro.MleFile.exists())) then outdir.MleFile.mkDir();
        List.iter (fun next ->
            let fileName = shortName (indir.MleFile.fullPath()) 
                (next.MleFile.fullPath()) in
            let newsubdir = outdir.MleFile.subEdFile fileName in
            copyFileObj userOut next newsubdir
        ) (indir.MleFile.subRdFiles())    
    )        
             
let start userIn userOut authlist = 
	match authlist with 
	| Readable fromFile :: Editable outFile :: []  -> 
		copyFileObj userOut fromFile outFile; 0
	| _ -> userOut "To use dircp, an input folder and output folder are required"; 1
   
	
