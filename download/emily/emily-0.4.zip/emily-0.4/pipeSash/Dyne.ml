(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   

open Far
    
exception BadType of string
exception BadDyne of string


let stringOf x = match x with
    | Int a -> string_of_int a
    | Str a -> a
    | Unit -> "Unit"
    | Appliable (Proxy a) -> "Proxy"
    | Appliable (Local a) -> "Local"
    | Appliable (ApplyVow a) -> "ApplyVow"
    | Vow a -> "Vow"
    | Err a -> "Err: " ^ a
    | List a -> "List, length: " ^ (string_of_int (List.length a))
    | True -> "True"
    | False -> "False"

let error badArg comment = 
    Err ("Wrong Type: " ^ (stringOf badArg) ^ " context: " ^ comment)

let raiseType badArg comment = raise (BadType (stringOf 
    (error badArg comment))) 
let raiseDyne bad comment = raise (BadDyne (stringOf (error bad comment)))  
    
let dyne_of_bool a = if a then True else False

let (+:) a b = match (a, b) with | Int a, Int b -> Int (a + b)
    | _ -> error a "adding"
let (-:) a b = match (a, b) with | Int a, Int b -> Int (a - b)
    | _ -> error a "subtracting"
let ( *:) a b = match (a, b) with | Int a, Int b -> Int (a * b)
    | _ -> error a "multiplying"
let (/:) a b = match (a, b) with | Int a, Int b -> Int (a / b)
    | _ -> error a "dividing"
let (<:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a < b)
    | _ -> error a "lessing"
let (>:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a > b)
    | _ -> error a "greatering"
let (<=:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a <= b)
    | _ -> error a "lessequaling"
let (>=:) a b = match (a, b) with | Int a, Int b -> dyne_of_bool (a >= b)
    | _ -> error a "greaterequaling"
let (^:) a b = match (a, b) with | Str a, Str b -> Str (a ^ b) 
    | _ -> error a "concating"

let escInt = function | Int x -> x | bad -> raiseType bad "not Int"        
let escStr = function | Str x -> x |bad -> raiseType bad "not Str" 
let escBool = function | True -> true | False -> false | bad -> raiseType bad "not Bool"
let escVow = function | Vow x -> x | bad -> raiseType bad "not Vow"
let escList = function | List x -> x | bad -> raiseType bad "not List" 
let escApp = function | Appliable x -> x | bad -> raiseType bad "not Appliable" 
    
let apply f args = match f with
    | Appliable (Local f) -> f args
    | _ -> error f "applying"        
let ( ->: ) f args = apply f args

let sendA f args = match f with
    | Appliable f -> send f args
    | bad -> let (brokenVow, resolver) = Vow.make() in
        resolver (Vow.Broken (BadType (stringOf bad ^ "sendA")));
        brokenVow
    
(* obj:sendable appliable message:string args:sendable *)    
let sendM obj message args = match obj with
    | Appliable o -> send o (List [Str message; args])
    | bad -> let (brokenVow, resolver) = Vow.make() in
        resolver (Vow.Broken (BadType (stringOf bad ^ "sendM")));
        brokenVow
    
let callM obj message args = match obj with
    | Appliable (Local f) -> f (List [Str message; args])
    | bad -> Err (stringOf bad ^ "not local for callM")
  
(* msgFuncPairs: list of (string*Far.func), example 
[("getVal", fun (null:dyne) -> !myVal);
("setVal", fun x ->  myVal := x)]
to use: sendM obj "setVal" (Int 1)
*)            
let makeObj msgFuncPairs = 
    let obj msg = match msg with
        | List [Str methodd; args] -> Kit.findCatch (fun next -> fst next = methodd)
            msgFuncPairs
            (fun next -> (snd next ) args)
            (fun () -> Err ("Message Not Understood: " ^ methodd))  
        | bad -> Err ("Not Message sent to object: " ^ (stringOf bad)) in
    Appliable (Local obj)        
  
