
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   

type event = unit -> unit

(* !!! gotta check in Emily, does this pattern for creating the one true 
   event queue defeat the static mutable check? it is a static mutable,
   but it does not look like it to the human eye, is the parser fooled?
*)
let (add, start, clear, exitGracefully) =
	let theOneTrueEventQueue = Q.make() in
	let exitCodeX = ref 0 in

    let add (nextEvent) = Q.push theOneTrueEventQueue nextEvent in
       (* theOneTrueEventQueue := List.concat 
        [!theOneTrueEventQueue;[nextEvent]] in *)

    (*let rec start() = 
        match !theOneTrueEventQueue with
            | [] -> !exitCodeX
            | nextEvent :: remainingEvents ->
                theOneTrueEventQueue := remainingEvents;
                (try nextEvent() with
                    | Failure reason -> prerr_string 
                        ("event died reason: " ^ reason)
                    | _ -> prerr_string "event died, going to next event";);
                start() in *)
    let rec start() = 
        Q.popCatch theOneTrueEventQueue
            (fun nextEvent -> (try nextEvent() with
                    | Failure reason -> prerr_string ("event died reason: " ^ reason)
                    | _ -> prerr_string "event died, going to next event";);
                start())
            (fun () -> !exitCodeX) in                

    let clear() = Q.clear theOneTrueEventQueue in
    
    (* pass in a function or throw exception to make this pass emily *)
    let exitGracefully (exitCode:int) = clear();
        Q.push theOneTrueEventQueue 
            (fun () -> exitCodeX := exitCode; 
                Q.clear theOneTrueEventQueue ) in
        
    (add, start, clear, exitGracefully)

