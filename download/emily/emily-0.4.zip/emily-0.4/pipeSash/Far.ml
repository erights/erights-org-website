
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   
let (>.) = Kit.(>.)
    
type token = Token of string
type connection = {input : Unix.file_descr; output : Unix.file_descr}
type proxy = {id : token; location : connection }

type appliable = Local of func | Proxy of proxy 
    | ApplyVow of appliable Vow.vow

and sendable = Int of int | Str of string | Unit | Err of string 
    | True | False | List of sendable list | Appliable of appliable 
    | Vow of vowS
and func = sendable -> sendable
and vowS = sendable Vow.vow
   
type message = {returnNonce : token; funcId : token; args : sendable}
type carrier = Msg of message | Return of (token * sendable) |
    Resolution of (token * sendable Vow.resolution)

type funcRef = {refId :token; func : appliable}
type returnVal = {nonce: token; solver: sendable Vow.resolver}

type vowRecord = {
    vowNonce : token;
    forwardedVow : vowS;
    receivedVowResolver : sendable Vow.resolver option;
    mutable forwardedLocations :  Unix.file_descr list
}

let stringOf x = match x with
    | Int a -> string_of_int a
    | Str a -> a
    | Unit -> "Unit"
    | Appliable (Proxy a) -> "Proxy"
    | Appliable (Local a) -> "Local"
    | Appliable (ApplyVow a) -> "ApplyVow"
    | Vow a -> "Vow"
    | Err a -> "Err: " ^ a
    | List a -> "List, length: " ^ (string_of_int (List.length a))
    | True -> "True"
    | False -> "False"

let debugChild = ref "neither"

let trace text = !debugChild ^ " " ^ text >. Kit.trace

let (<<-) = Vow.(<<-)

let randInited = ref false

let makeToken purpose =
    if not !randInited then (
        Random.self_init();
        randInited := true;
    );
    let chars = 
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" in
    let randStr = ref (purpose ^ "_") in
    for i = 0 to 25 do
        let nextChar = " " in
        nextChar.[0] <- chars.[Random.int (String.length chars)];
        randStr := !randStr ^ nextChar;
    done;
    Token !randStr

let string_of_token token = let (Token x) = token in x         
    
let makeProxy id conn = {id = id; location = conn}    

module FuncRefsBoss = struct

    let (getId, getFunc, resetRefs, addFunc) = 
        let funcRefs = ref ([] : funcRef list) in
        
        let getId func = 
            trace ( "refboss getid");
            Kit.findCatch
                (fun nextRef -> match nextRef.func with
                    | Local f -> f = func
                    | _ -> false)
                !funcRefs
                (fun found -> trace "found funcid"; found.refId)
                (fun unit -> let newId = makeToken "ref" in
                    trace ("new near, new token: " ^ (string_of_token newId));
                    funcRefs := {refId = newId; func = Local func}
                        :: !funcRefs;
                    newId) in
                    
        let getFunc id optConn =
            trace ( " refboss getfunc for id " ^ (string_of_token id));
            Kit.findCatch (fun next -> next.refId=id)
                !funcRefs
                (fun found -> trace "found func"; found.func)
                (fun () -> match optConn with
                    | None -> let err = 
                            "fetchFunc seeking token, no conn: " ^ 
                            (string_of_token id) ^ "\n" in
                        prerr_string ("Error, creating dummy func " ^ err);
                        let dummy arg = prerr_string 
                            ("Err, using dummy func " ^ err); Unit in
                        Local dummy
                    | Some conn -> trace ( " constructing proxy for id");
                        let newProxy = Proxy {
                            id = id;
                            location = conn
                        } in
                        funcRefs := {refId = id; func = newProxy}
                            :: !funcRefs;
                        newProxy) in
                
        let resetRefs() = funcRefs := [] in
        
        let addFunc id func = 
            funcRefs := {refId = id; func = func} :: !funcRefs in
            
        (getId, getFunc, resetRefs, addFunc)
end

module ReturnsBoss = struct
    let (addRet, withdraw, resetRets) =
        let returns = ref [] in
    
        let addRet nonce solver =
            returns := {nonce = nonce; solver = solver} :: !returns in
            
        let withdraw nonce = trace ( " retboss withdrawing " ^ 
            (string_of_token nonce));            
            Kit.findCatch (fun next -> nonce=next.nonce)
                !returns
                (fun result ->
                    returns := List.filter (fun next -> not(nonce=next.nonce))
                        !returns;
                    result)
                (fun () -> trace ( "retboss, nonce not found: " ^ (string_of_token nonce));
                    let _, solver = Vow.make() in
                    {nonce = nonce; solver = solver}
                ) in
                
        let resetRets () = returns := [] in
        
        (addRet, withdraw, resetRets)
end

let rec readln indesc =
    let getChar () =
        let charbuf = " " in
        if (Unix.read indesc charbuf 0 1) = 0 then "\n"
        else charbuf
    in
    let buf = ref "" in
    let next = ref "" in
    while (!next <> "\n") do
        buf := !buf ^ !next;
        next := getChar()
    done;
    !buf

let write outdesc text = ignore (Unix.single_write outdesc text 0 
    (String.length text))

(* This is terrible, the global mutable for vowRecords sitting in public.
   How do I fix this? *)
let vowRecords = ref []

let rec serializeSendable outDesc sendable =
    let formStringData message =
        string_of_int (String.length message) ^ "\n" ^ message in
    match sendable with
    | Int num -> write outDesc ("Int\n" ^ (string_of_int num) ^ "\n")
    | Str text -> write outDesc  ("Str\n" ^ (formStringData text))
    | True -> write outDesc "True\n" 
    | False -> write outDesc "False\n"
    | Unit -> write outDesc  "Unit\n"
    | Err prob -> write outDesc  ("Err\n" ^ (formStringData prob))
    | Appliable (Local func) -> trace "serializing Appliable";
        let transId = FuncRefsBoss.getId  func in
        write outDesc ("Appliable\n");
        write outDesc ((string_of_token transId) ^ "\n")
    | Appliable(Proxy farFunc) -> trace "serializing farfunc";
        write outDesc ("Appliable\n");
        write outDesc ((string_of_token farFunc.id) ^ "\n");
    | Appliable(ApplyVow applyVow) -> trace "serializing appliable vow";
        write outDesc ("AppliableVow\n");
        write outDesc ("??? this has not yet been figured out\n")
    | Vow vow -> trace "serializing vow";
        let transId = vowBoss_forwardingVow vow outDesc in
        write outDesc ("Vow\n");
        write outDesc ( string_of_token transId ^ "\n")
    | List l -> write outDesc ("List\n");
        write outDesc (string_of_int (List.length l) ^ "\n");
        List.iter (fun elem ->
            serializeSendable outDesc elem)
            l            
    (* | _ -> prerr_string "serializeSendable for type not yet implemented\n" *)

and

serializeCarrier outDesc carrier =
    (match carrier with
    | Msg message -> trace ( " serializing msg");
        write outDesc "Msg\n";
        write outDesc (string_of_token message.returnNonce ^ "\n");
        write outDesc (string_of_token message.funcId ^ "\n");
        serializeSendable outDesc message.args
    | Return (nonce, answer) -> trace ( " serializing return");
        write outDesc "Return\n";
        write outDesc (string_of_token nonce ^ "\n");
        serializeSendable outDesc answer
    | Resolution (nonce, res) -> trace (" serializing resolution");
        write outDesc "Resolution\n";
        write outDesc (string_of_token nonce ^ "\n");
        (match res with
        | Vow.Broken _ -> serializeSendable outDesc (False);
            serializeSendable outDesc Unit
        | Vow.Fulfilled answer -> serializeSendable outDesc (True);
            serializeSendable outDesc answer
        ) )

and
(* once upon a time, vowBoss was the name of a record with 3 methods. 
    Now it is 3 methods prefixed with vowBoss in the name. The 
    intertwining co-usage among these functions that are anded 
    together is remarkable. *)
 vowBoss_forwardingVow = (fun vow desc ->
    Kit.findCatch (fun nextRec -> nextRec.forwardedVow = vow)
        !vowRecords
        (fun foundRec ->
            Kit.findCatch (fun nextDesc -> nextDesc = desc)
                foundRec.forwardedLocations
                (fun foundDesc -> ())
                (fun () -> foundRec.forwardedLocations <-
                    desc :: foundRec.forwardedLocations);
            foundRec.vowNonce
        )
        (fun () -> let newToken = makeToken "forwardedVow" in
            let newRecord = {
                vowNonce = newToken;
                forwardedVow = vow;
                receivedVowResolver = None;
                forwardedLocations = [desc]
            } in
            vowRecords := newRecord :: !vowRecords;
            (* when this newly recorded vow resolves, fire event to
               forward the resolution to all recipients, then delete
               this vow from the list, it has been consumed*)
            Vow.whenCatchOnly vow (fun res ->
                List.iter (fun nextDesc ->
                    serializeCarrier nextDesc (Resolution (newToken, res)))
                    newRecord.forwardedLocations;
                vowRecords := List.filter 
                    (fun next -> next <> newRecord) !vowRecords
            );
            newToken
        ) )

and

vowBoss_vowArrived = (fun nonce ->
    Kit.findCatch (fun nextRec -> nextRec.vowNonce = nonce)
        !vowRecords
        (fun foundRec -> foundRec.forwardedVow)
        (fun () -> let newVow, solver = Vow.make() in
            let newRec = {vowNonce = nonce;
                forwardedVow = newVow;
                receivedVowResolver = Some solver;
                forwardedLocations = []
            } in
            vowRecords := newRec :: !vowRecords;
            newVow) )

and

vowBoss_resolutionArrived = (fun resId res ->
    Kit.findCatch (fun nextRec -> nextRec.vowNonce = resId)
    !vowRecords
    (fun foundRec -> (match foundRec.receivedVowResolver with
        | None -> trace ("vowboss has res for vow with no resolver")
        | Some solver -> solver res;
            List.iter (fun nextChan ->
                serializeCarrier nextChan (Resolution (resId, res)) )
                foundRec.forwardedLocations) )
    (fun () -> trace ("vowboss resolutionarrived for nonexistent vow, id: " 
        ^ (string_of_token resId)) ) )

let getToken conn = Token (readln conn.input)            

let rec deserializeSendable conn =
    let readStringData() =
        let length = int_of_string (readln conn.input) in
        let buf = String.make length ' ' in
        let realLength = Unix.read conn.input buf 0 length in
        if not(realLength = length) then prerr_string "readstringdata short some char";
        buf in
    (match readln conn.input with
    | "Int" -> trace "deserializing int"; 
        Int (int_of_string (readln conn.input))
    | "Str" -> Str (readStringData())
    | "True" -> True
    | "False" -> False
    | "Unit" -> trace "deser unit"; Unit
    | "Err"  -> Err (readStringData())
    | "Vow" -> trace "deser vow";
        let vowNonce = getToken conn in
        Vow (vowBoss_vowArrived vowNonce)
    | "Appliable" -> trace "deserializing appliable";
        let id = getToken conn in
        Appliable (FuncRefsBoss.getFunc id (Some conn)) 
    | "List" -> trace "deserializing list";
        let length = int_of_string (readln conn.input) in
        let newList = ref  [] in
        for i = 1 to length do
            newList := deserializeSendable conn :: !newList 
        done;
        List (List.rev !newList) 
    | unmatched ->
        trace ( "unmatched sendable: " ^ unmatched);
        (* TODO: empty/discard the channel, everything is dead *)
        Err ("deserializing unimplemented type: " ^ unmatched))

let deserializeCarrier conn =
    let deadChan detail = prerr_string (
        "received bad carrier " ^ detail ^ "\n");
        raise (Failure ("received bad carrier: " ^ detail)) in
    let msgType = readln conn.input in
    match msgType with
    | "Msg" -> trace "deserializing msg";
        let ret = getToken conn in
        trace ("msg has return nonce of : " ^ (string_of_token ret));
        let funcId = getToken conn in
        let arg = deserializeSendable conn in
        Msg {returnNonce = ret; funcId = funcId; args = arg}
    | "Return" -> trace ( "deserializing return");
        let ret = getToken conn in
        let answer = deserializeSendable conn in
        Return (ret, answer)
    | "Resolution" -> trace ("deserializing resolution");
        (match (getToken conn,
            deserializeSendable conn,
            deserializeSendable conn)  with
        | resNonce, True, answer -> 
            let res = Vow.Fulfilled answer in
            Resolution (resNonce, res)    
        | resNonce, False, answer -> 
            let res = Vow.Broken(Failure "broken promise over wire") in
            Resolution (resNonce, res)        
        | _ -> deadChan "resolution deserialization bad")
    | _ -> deadChan "neither msg nor return nor resolution"

let rec send appliable arg = (match appliable with
    | Local func -> func <<- arg
    | Proxy farFun ->
        let (prom, solver) = Vow.make() in
        let nonce = makeToken "nonce" in
        trace ( " sending with nonce " ^ (string_of_token nonce));
        ReturnsBoss.addRet nonce solver;
        serializeCarrier farFun.location.output
            (Msg {returnNonce = nonce; funcId = farFun.id; args = arg});
        prom
    | ApplyVow vow -> let prom, solver = Vow.make() in
        Vow.whenCatchOnly vow (fun answerRes -> match answerRes with
            | Vow.Fulfilled sendableAnswer -> 
                Vow.whenCatchOnly (send sendableAnswer arg)
                    (fun innerRes -> solver innerRes)
            | Vow.Broken prob -> solver (Vow.Broken prob)
        );
        prom
    )

module CommWatcher = struct
    let (addConn, runWatch, resetConns, start) =
        let connections = ref [] in
        
        let addConn conn =
            connections := conn :: !connections in
        
        let rec runWatch () =
            (*Unix.sleep 1;*)
            let incomings =  List.map (fun next -> next.input) 
                !connections in
            let (available, _, _) = Unix.select incomings [] [] 1.0 in
            List.iter (fun nextInput ->
                try (
                    let conn = List.find 
                        (fun nextConn -> nextInput = nextConn.input)
                        !connections in
                    match deserializeCarrier conn with
                    | Resolution (nonce, answerRes) ->
                        vowBoss_resolutionArrived nonce answerRes
                    | Return (nonce, answer) -> 
                        "!!!got return: " ^ stringOf answer >. trace; 
                        (ReturnsBoss.withdraw nonce).solver
                            (Vow.Fulfilled answer)
                    | Msg message -> let targetFunc = 
                        FuncRefsBoss.getFunc message.funcId None in
                        let answerVow = send targetFunc message.args in
                        ignore (Vow.whenDo answerVow (fun answer ->
                            serializeCarrier conn.output
                                (Return (message.returnNonce, answer))))
                )  with _ -> prerr_string 
                    ( "crashed on deserializing carrier\n")
            ) available;
            ignore (runWatch <<- ()) in
            
        let resetConns () = connections := [] in
        
        let start () = runWatch(); EventQueue.start() in
        
        (addConn, runWatch, resetConns, start)
end

let resetChild () = CommWatcher.resetConns();
    FuncRefsBoss.resetRefs();
    ReturnsBoss.resetRets();
    EventQueue.clear();
    ignore (Random.int (2)) (* offset the pseudorandoms so no 
                                duplicates with the parent *)
    
let commWatcher_addConn = CommWatcher.addConn
let commWatcher_start = CommWatcher.start 
let funcRefsBoss_addFunc = FuncRefsBoss.addFunc

