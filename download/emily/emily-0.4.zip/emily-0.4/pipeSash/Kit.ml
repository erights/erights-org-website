(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)

(* should trace do full-power userOut style labeling? *)
let trace text = prerr_string (text ^ "\n"); flush stderr

(* 'a 'b findcatch : 
    ('a -> bool) -> 'a list -> ('a -> 'b) -> (unit -> 'b) -> 'b *)
let rec findCatch test items foundFunc noneFunc = match items with
    | [] -> noneFunc()
    | item :: tail -> if test item then foundFunc item
        else findCatch test tail foundFunc noneFunc
             
let ( >. ) x f = f x        


