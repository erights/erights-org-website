(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

type filecore = {path:string}

let makeFullPath path = if not (Filename.is_relative path) then path
	else Filename.concat (Sys.getcwd()) path

let exists file () = Sys.file_exists file.path
let isDir file () = (exists file ()) && 
	((Unix.stat file.path).Unix.st_kind = Unix.S_DIR)
	
let outChannel file () = open_out_bin file.path
let inChannel file () = open_in_bin file.path
let getBytes file () = 
	let chan = inChannel file () in
	let length = in_channel_length chan in
	let buf = String.make length ' ' in
	let _ = input chan buf 0 length in
	close_in chan;
	buf
	
let setBytes file bytes = 
	let chan = outChannel file () in
	output_string chan bytes;
	close_out chan

(* remember, strings are mutable! *)
let fullPath file () = String.copy file.path

let mkDir file () = Unix.mkdir file.path 0o777

let createNewFile file () = 
	let chan = outChannel file () in
	close_out chan 

let subFile makeFile file subPath = 
	let dotdot = Str.regexp ".*[.][.].*" in
    let hasDotdot = Str.string_match dotdot subPath 0 in
    let midSlash = if hasDotdot 
    	then
	    	raise (Invalid_argument "path has ..")
	    else
	    	if String.get file.path 
	    		((String.length file.path) -1) = '\\' then
	    		"" 
	    	else "\\" in
	makeFile (file.path ^ midSlash ^ subPath)
	
let subFiles makeFile file () = 
	let names = Array.to_list (Sys.readdir file.path) in
	List.map (fun name -> subFile makeFile file name) names
    				
let rec makeReadable pathName = 
	let myFile = {path = makeFullPath pathName} in
	{
	 MleFile.isDir = isDir myFile;
	 exists = exists myFile;
	 subRdFiles = subFiles makeReadable myFile;
	 inChannel = inChannel myFile;
	 getBytes = getBytes myFile;
	 fullPath = fullPath myFile;
	 subRdFile = subFile makeReadable myFile;
	}

let rec makeEditable pathName =
	let myFile = {path = makeFullPath pathName} in
	{
	 MleFile.ro = makeReadable pathName;
	 outChannel = outChannel myFile;
	 setBytes = setBytes myFile;
	 createNewFile = createNewFile myFile;
	 mkDir = mkDir myFile;
	 delete = delete myFile;	
	 subEdFile = subFile makeEditable myFile;
	 subEdFiles = subFiles makeEditable myFile;	
	} 

and delete file () = if exists file () then
	(if not (isDir file ()) then Sys.remove file.path
	else ( 
		List.iter (fun sub -> sub.MleFile.delete ()) (subFiles makeEditable file () );
		Unix.rmdir file.path )
	)
