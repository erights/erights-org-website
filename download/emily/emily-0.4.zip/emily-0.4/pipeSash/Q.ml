(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   

type 'a carrier = {data: 'a; mutable next: 'a carrier option}
type 'a q = {mutable head: 'a carrier option; 
    mutable tail: 'a carrier option}
exception Empty

let make () = {head = None; tail = None}

let push q data = 
    let newElem = Some {data = data; next = None} in
    let oldTail = q.tail in
    match q.tail with
    | None -> assert (q.head = None);
        q.head <- newElem;
        q.tail <- newElem;
    | Some oldTail -> assert (q.head <> None);
        oldTail.next <- newElem;
        q.tail <- newElem
        
let isEmpty q = q.head = None             
            
let pop q =
    match q.head with
    | None -> raise Empty
    | Some oldHead -> 
        q.head <- oldHead.next;
        if q.head = None then q.tail <- None;
        oldHead.data
        
let popCatch q foundfunc emptyfunc =
    if isEmpty q then
        emptyfunc()
    else foundfunc (pop q)
    
let clear q = q.tail <- None; q.head <- None;               


        
  
