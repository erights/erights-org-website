
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   


type vat = {kill: unit -> unit; main: Far.appliable }

let make func =
    let mainFuncId = Far.makeToken "mainFuncId" in
    let parentToChildPipe = Unix.pipe() in
    let childToParentPipe = Unix.pipe() in

    match Unix.fork() with
    | 0 -> Kit.trace "starting child";
        Far.debugChild := "child";
        Far.resetChild();
        let instream, _ = parentToChildPipe in
        Unix.set_nonblock instream;
        let _, outstream = childToParentPipe in
        let conn = {Far.input = instream; Far.output = outstream} in
        Far.commWatcher_addConn conn;
        Far.funcRefsBoss_addFunc
            mainFuncId (Far.Local func);
        ignore (Far.commWatcher_start());
        exit 0
    | pid -> Kit.trace "continuing parent";
        Far.debugChild := "parent";
        let instream, _ = childToParentPipe in
        Unix.set_nonblock instream;
        let _, outstream = parentToChildPipe in
        let conn = {Far.input = instream; Far.output = outstream} in
        let mainProxy = Far.makeProxy mainFuncId conn in
        Far.funcRefsBoss_addFunc
            mainFuncId (Far.Proxy mainProxy);
        Far.commWatcher_addConn conn;
        {
            kill = (fun () -> Unix.kill pid Sys.sigkill);
            main = Far.Proxy mainProxy
        }
