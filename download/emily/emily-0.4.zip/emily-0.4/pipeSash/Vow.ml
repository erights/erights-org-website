
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   
(* Dyne is an experimental enhancement to Emily that supports promise 
   pipelining among processes on a single computer, enabling effective
   use of multicore and multiprocessor systems in a robust reliable
   deadlock-free fashion *)
   

open Kit

type 'a resolution = Broken of exn | Fulfilled of 'a
type 'a status = Pending | Resolved of 'a resolution
type 'a action = 'a resolution -> unit
type 'a vow = {
    mutable content: 'a status;
    mutable actions: 'a action list
}
type 'a resolver = 'a resolution -> unit

let make() =
    let promise = {content=Pending;actions=[]} in 
    let resolve solution =
        match promise.content with
        | Pending -> promise.content <- Resolved solution;
            List.iter (fun nextAction ->
                Kit.trace "queueing action from resolver";
                let newEvent() = nextAction solution in
                EventQueue.add newEvent )
                (List.rev promise.actions);
            promise.actions <- []
        | Resolved _ -> ()
    in
    (promise, resolve)
    
let wrap a = {content = Resolved (Fulfilled a); actions = []}   

let (<<-) func arg = 
    let (vow, resolve) = make() in 
    let newEvent() =
        try 
            resolve (Fulfilled (func arg))
        with prob -> resolve (Broken prob)
    in
    EventQueue.add newEvent;
    vow           

let post aVow action = match aVow.content with
        (* actions are in reverse order, but they are unreversed 
        during resolution*)
    | Pending -> aVow.actions <- action :: aVow.actions
    | Resolved res -> EventQueue.add (fun () -> action res)

let whenDo aVow transform =
    let (bVow, bSolver) = make() in
    let newAction resolution = 
        let transformResult = match resolution with
            | Fulfilled answer -> 
                (try
                    Fulfilled (transform answer)
                with prob -> "throw during whenDo">.trace;
                    Broken prob )
            | Broken prob -> "whenDo got prob" >. trace;
                Broken prob in
        bSolver <<- (transformResult) >. ignore 
    in
    post aVow newAction;
    bVow

let whenCatch aVow resolutionTransform =
    let (bVow, bSolver) = make() in
    let newAction resolution =
        let transformResult = 
            try
                resolutionTransform resolution
            with prob -> Broken prob
        in
        bSolver <<- transformResult >. ignore
    in
    post aVow newAction;
    bVow

let whenCatchOnly aVow transform =
    let newAction resolution = ignore (transform resolution) in
    post aVow newAction

let unVow vowVow = let (prom, solver) = make() in
    whenCatchOnly vowVow (fun outerVowResolution ->
        (match outerVowResolution with
        | Broken prob -> solver (Broken prob)
        | Fulfilled innerVow ->
            whenCatchOnly innerVow (fun answerResolution ->
                solver answerResolution)
        ));
    prom
    
let nowVal avow = match avow.content with 
	| Pending -> None
	| Resolved  x -> Some x
	
(* we know by human inspection that nowVal can only return fulfilled , 
    how do we embody that knowledge here? *)	
let extract v = match nowVal v with
    | Some Fulfilled r -> r
    | _ -> raise (Failure "invariant violated")
            
let both vow1 vow2 =
    let (bothFulfilledVow, resolve) = make() in
    let unFulfilledCount = ref 2 in
    let countDown r = match r with
        | Broken err -> resolve (Broken err)
        | Fulfilled _ -> unFulfilledCount := !unFulfilledCount -1;
            if unFulfilledCount.contents <= 0 then 
                resolve (Fulfilled (extract vow1, extract vow2)) in
    whenCatchOnly vow1 countDown;
    whenCatchOnly vow2 countDown;
    bothFulfilledVow
            
let all vows = let (allFulfilledVow, resolve) = make() in
    let unresolvedCount = ref (List.length vows) in
    List.iter (fun v -> 
        whenCatchOnly v (function
            |Fulfilled _ -> unresolvedCount := !unresolvedCount - 1;
                if !unresolvedCount <= 0 then 
                    let answers = List.map extract vows in
                    resolve (Fulfilled answers)
            | Broken trouble -> resolve (Broken trouble)))
        vows;
    if !unresolvedCount = 0 then resolve (Fulfilled []);        
    allFulfilledVow        

