
# Copyright 2005 Marc D. Stiegler under the terms of the MIT X license
# found at http://www.opensource.org/licenses/mit-license.html
   

OCAMLLIB='c:/cygwin/lib/ocaml'

**compile dyne power interfaces
ocamlopt -c Kit.mli Q.mli EventQueue.mli Vow.mli Far.mli Vat.mli Dyne.mli

**compile dyne modules
ocamlopt -c Kit.mli Q.mli EventQueue.mli Vow.mli Far.mli Vat.mli Dyne.mli Kit.ml Q.ml EventQueue.ml Vow.ml Far.ml Vat.ml Dyne.ml

**compile emily program: emilyopt poweboxFolder appFolder outputFile
emilyopt sashDyne pipetest pipetest.exe
