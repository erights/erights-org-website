(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)


(*** Sash Powerbox ***)
open SashInterface;;

let auths = List.map (fun arg ->
	let argUnprefixed = String.sub arg 1 (String.length arg - 1) in 
	match arg.[0] with
		  '=' ->  Readable (MleFileMaker.makeReadable argUnprefixed)
		| '+' ->  Editable (MleFileMaker.makeEditable argUnprefixed)
		| '^' -> (match argUnprefixed with 
					| "time" -> Time Unix.time 
					| "stdout" -> Stdout stdout
					| _ -> raise (Invalid_argument "bad special(^) request") )
		| _ -> Str arg
	) (List.tl (Array.to_list Sys.argv)) in

let commandName = Sys.argv.(0) in

let userOut message = 
	print_string ("Command " ^ commandName ^ " said: \n> ");
	let currentLineCharCount = ref 0 in
	let newline() = 
		output_string stdout "\n> ";
		currentLineCharCount := 0 
	in
	String.iter (fun next ->
		let nextInt = int_of_char next in
		if (nextInt >= 32 && nextInt <= 126) then (
			output_char stdout next;
			currentLineCharCount := !currentLineCharCount + 1;
			if (!currentLineCharCount > 80) then newline()			
		) else if (next = '\n') then
			newline()
		) message;
	output_string stdout "\n"
in

(* remember the vats created, kill them all during finalization *)
let makeVat (i:int) = Vat.make (CapMain.vatFuncs i) in
(* probably make startEvents a 1-time-only invocation*)
let startEvents() = Far.commWatcher_start() in

let endowment = {makeVat = makeVat; 
    startEvents = startEvents;
    exitGracefully = EventQueue.exitGracefully;
    standin = stdin; 
    userOut = userOut} in

exit (CapMain.start endowment auths)

		
