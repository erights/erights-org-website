
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
 
open Kit
open Far
open Dyne
  
let dyneStepIndex() = 0 
let sendableCounterIndex() = 1

module TestMutableStatics = struct
    (*let pi = 3.14*)
    (*** Serious bug in verifier, the content variable is not picked
         up as a mutable static ***)
    let (getX, setX) =
        let content = ref 0 in
        let get() = content.contents in
        let set x = content := x in
        (get, set)
end

module TestDyne = struct

    open Far
    open Dyne

    (* factorial *)
    let rec facDyne n = 
        if True = (n <=: (Int 1)) then Int 1
        else n *: (facDyne (n -: (Int 1)))
        
    let makeCounterPair (null:sendable) = 
        let count = ref (Int 0) in
        let inc (null:sendable) = 
            count := !count +: (Int 1);
            !count
        in
        let dec (null:sendable) = 
            count := !count -: (Int 1);
            !count
        in
        List [Appliable(Local inc); Appliable(Local dec)]
        
    let useCounter makeCounterPair =
        match makeCounterPair Unit with 
        | List [incr; decr] -> 
            trace ("inc: " ^ (stringOf ( incr ->: Unit)));
            trace ("dec: " ^ (stringOf (apply decr Unit)));
            Unit
        | bad -> trace (stringOf bad ^ " not counter pair"); Unit
        
    let printDyne sent = trace (stringOf sent); Unit
    
    let makeFarUseCounter (null:sendable) = 
        let useCounter nameCounterPrinter =
            let numRunsLeft = ref 3 in
            (match nameCounterPrinter with
            | List[Str name; counter; printer] -> 
                let rec runCount() = 
                    ignore (Vow.whenDo (sendA  counter Unit)
                        (fun newCount -> ignore 
                            (sendA printer (Str (name ^ " reports " ^
                                (stringOf newCount) ^ " is new count" ^ "\n")));
                            numRunsLeft := !numRunsLeft - 1;                    
                            if !numRunsLeft > 0 then runCount()
                    )) in
                runCount()                               
            | bad -> raiseDyne bad "args in useCounter" );
            Unit in            
        Appliable(Local useCounter)
        
    let makeFarDBElement (unit:sendable) = 
        let name = ref (Str "") in
        let phone = ref (Str "") in
        makeObj [
            ("setName", fun nameStr -> name := nameStr; Unit);
            ("setPhone", fun phoneStr -> phone := phoneStr; Unit);
            ("getRecord", fun (null:sendable) ->
                List [!name; !phone]  )]
              
    
    (* computation for parallel fac, in straight Emily *)
    let computeStep start step n = 
        let nowcount = ref 1 in 
        let nowstep = ref start in
        while nowstep.contents <= n do 
            nowcount := nowcount.contents * nowstep.contents;
            nowstep := nowstep.contents + step;
        done;
        nowcount.contents
        
    (* coordination for parallele fac, in dyne *)    
    let dyneStep startStepN = match startStepN with
        | List [Int start; Int step; Int n] -> Int (computeStep start step n)
        | bad -> error bad "bad args for dyneStep"
        
    let paraFac nvats n makeVat =
        (* central compute manager *)    
        let total = ref 1 in
        let reportingSteppers = ref 0 in 
        let (resultVow, resolver) = Vow.make() in          
        for i = 1 to nvats do
            let nextVat =  dyneStepIndex()>.makeVat in
            let partialAnswerVow = Far.send nextVat.Vat.main 
                (List [Int i; Int nvats; Int n]) in
            Vow.whenCatchOnly partialAnswerVow
                (fun partialRes ->
                    nextVat.Vat.kill();
                    trace "got a parafac partial res";
                    match partialRes with 
                    | Vow.Fulfilled (Int stepAnswer) ->  
                        total := total.contents * stepAnswer ;
                        reportingSteppers := reportingSteppers.contents + 1;
                        if reportingSteppers.contents >= nvats then
                            resolver (Vow.Fulfilled total.contents)
                    | bad -> resolver (Vow.Broken (Failure "paraFac failed"))) ;
        done;
        resultVow   
                                      
        
    let run makeVat = 
         "fac 3 = " ^ (Int 3 >. facDyne >. stringOf) >. trace ;
        ignore (useCounter makeCounterPair);
        trace "starting makeCoundPair";
        (match makeCounterPair Unit with
            | List [incr; decr] ->
                let farUseCounter = makeFarUseCounter Unit in
                    ignore (apply farUseCounter ( List [Str "useCounter1";
                        incr;
                        Appliable (Local printDyne)]))
            | _ -> trace "bad counter" );
        let joe = makeFarDBElement Unit in
        ignore (sendM joe "setName" (Str "Joe"));
        ignore (sendM joe "setPhone" (Str "123"));
        ignore (Vow.whenDo (sendM joe "getRecord" Unit)
            (fun jrec -> trace ("ran joe record: " ^ (stringOf jrec));
                match jrec with 
                | List [Str name; Str phone] -> 
                    trace ("joe data: " ^ name ^ phone)
                | x -> raiseDyne x "not good joe rec"     )); 
        Vow.whenDo (paraFac 4 12 makeVat)(fun answer -> 
             "paraFac answer: " ^ string_of_int answer >.trace) >. ignore               
                   
end

module SimpleTests = struct

    open Vow
    
    (*****
    let testVows() =
        print_endline "now testing the Vow module";
    
        let vowReadLine2() = Vow.laterdo (fun () -> input_line stdin) in
        let vowedLine = vowReadLine2() in
        ignore (Vow.whenDo vowedLine (fun line ->
            print_endline ("line vow fulfilled: " ^ line)));
        print_endline "about to start event queue to read line with Vow module";
        EventQueue.start() in
    *****)    
    
    (*testVows();*)
    
    let makeFarVowUser() =
        let farVowUser sentListPrinterIntVow =
            match sentListPrinterIntVow with
            | Far.List [Far.Appliable printer; Far.Vow intVow] ->
                "!!SfarVowUser got printer and int" >. trace;
                ignore (whenDo intVow (fun farI -> (match farI with
                    | Far.Int i -> ignore (Far.send printer
                        (Far.Str ("resolved int: " ^ (string_of_int i) ) ) )
                    | _ -> trace "vow did not resolve to int")
                    ));
                Far.Unit
            | _ -> Far.Err "needs list of printer and int vow"
        in farVowUser
    
    let remotelyUsablePrinter farText = (match farText with
        | Far.Str text -> trace ("remote printer prints: " ^ text)
        | _ -> trace "remote printer got bad data"); Far.Unit
    
    (* given counter function ()->int , return sendable Far.Unit->Far.Int *)
    let makeSendableCounter targetCounter =
        let sCounter arg = match arg with
            | Far.Unit -> "sendable counter got unit, returning answer">.trace;
                Far.Int (targetCounter())
            | _ -> Far.Err "sendableCounter expected Far.Unit"
        in sCounter
    
    let makeCounter () =
        let current = ref 0 in
        let counter() = current := !current + 1;
            !current
        in counter
    
    (*
    let count = makeCounter() in
    print_endline ("inc counter: " ^ (string_of_int (count()))) ;
    let farCount = makeUtoIface count in
    let farResult = farCount Far.Unit in
    (match farResult with
        | Far.Int i -> print_endline ("inc far counter: " ^ (string_of_int i))
        | _ -> trace "farcount inc failed" );
        *)
    
    (* test the vat *)
    let printVowedInt intVow =
        "!!printVowedInt got intVow" >. trace;
        whenDo intVow (fun sentInt -> match sentInt with
            | Far.Int i -> trace ("\n>> It Worked. New Inc: " ^ 
                (string_of_int i))
            | bad -> "bad count: " ^ stringOf bad >. trace) 
    
    let test makeVat =
        let vatControl =  1 >. makeVat in
        let farCounter = vatControl.Vat.main in
        let firstVow = Far.send farCounter Far.Unit in
        let secondVow = Far.send farCounter Far.Unit in
        printVowedInt firstVow >. ignore;
        "send first vow to printVowedInt" >. trace;
        let finishedVow = printVowedInt secondVow in
        Vow.whenCatchOnly (Vow.both firstVow finishedVow )
            (fun x -> "\n!!!both finish and first resolved" >. trace);
        Vow.whenCatch finishedVow  (fun _ ->
                vatControl.Vat.kill(); Fulfilled ())         
                   

end        

let (<<-) = Vow.(<<-)

let vatFuncs i = "vatFuncs i: " ^ string_of_int i >. trace;
    match i with
    | 0 -> TestDyne.dyneStep
    | 1 -> SimpleTests.makeSendableCounter (
        SimpleTests.makeCounter()) 
    | bad -> Failure "bad vatfunc" >. raise 
    
let testQ () =
    let nq = Q.make() in
    Q.push nq "a";
    Q.push nq "b";
    Q.push nq "c";
    "q should be a: " ^ Q.pop nq >. trace;
    Q.push nq "d";
    "qu should be b: " ^ Q.pop nq >. trace;
    "qu should be c: " ^ Q.pop nq >. trace;
    "qu should be d: " ^ Q.pop nq >. trace 
    
let testResolutionSequence() = 
    let (prom, resolve) = Vow.make() in
    let p2 = Vow.whenDo prom (fun x -> "p1 resolved: " ^ x >.trace;
        trace <<- "trace queued in whendo on p1") in
    let p3 = Vow.whenDo p2 (fun y -> "p2 resolved" >. trace;
        trace <<- "trace queued in whendo on p2") in
    Vow.whenDo p3 (fun z -> "p3 resolved" >. trace) >. ignore;
    Vow.Fulfilled "r1" >. resolve         

let start endowments auths = 
    (*testQ();*)
    (*testResolutionSequence();*)
    (*TestDyne.run endowments.SashInterface.makeVat; *)
    
    let simpleDone = Vow.unVow
        (SimpleTests.test <<- endowments.SashInterface.makeVat) in
    Vow.whenDo simpleDone (fun () ->  
        "\n!!!should be termination, type enter to continue\n" >. trace;
        read_line()  >. ignore;
        endowments.SashInterface.exitGracefully 0) >. ignore;    
    
    endowments.SashInterface.startEvents()


    
    (**************************************************************)
    
    
    
    
(*** worker thread template ***)
(* needs num workers, sendable functions, accumulator *)
(* int -> (Unit -> sendable) list -> ('a -> sendable -> 'a) -> 'a vow *)
(* the numWorkers is useless, this will only work if the num of functions
   match the number of workers, since you can change functions once vat is
   spawned. An alternative: submit numworkers, submit
   a single function, and submit a list of sendables which are the sets of
   arguments to send to the single function that is replicated on all workers
   type: int -> (sendable -> sendable) -> sendable list -> 
        ('a -> sendable -> 'a) -> 'a -> 'a vow
   i.e., runWorkers numWorks workFunc argLists accumulater baseAnswer
   
   *)
   
(*
runWorkerVats numWorkers functions answerAccumulator baseAnswer
*)

(* to use, paraFac *)
(*
let functions = ref [] in
for i = 1 to nvats do
    let next (null:sendable) = Int (partialFac i nvats n) in
    functions := next :: functions.contents;
done;
let accum current newPartial = total := escInt newPartial * current in 
Void.whenCatchOnly (runWorkerVats nvats functions accum) 
    (fun answerRes -> match answer with
    | Vow.Fulfilled answer -> print_endline (string_of_int answer)
    | Vow.Broken x -> print_endline ("failed"))
    
alternate version with a single func
let argSets = ref [] in
for i = 1 to nvats do
    let nextArgSet = List[Int i; Int nvats; Int n] in
    functions := next :: functions.contents;
done;
let accum current newPartial = total := escInt newPartial * current in 
Void.whenCatchOnly (runWorkers nvats paraFunc argSets accum 1)
    (fun answerREs -> match answerRes with
    | Vow.Fulfilled answer -> print_endline (string_of_int answer)
    | Vow.Broken x -> print_endline ("failed"))
*)    
(*** end worker thread template ***)

(* state monad  in E

    def stateM {
      to then(action1, func) {
        return fn s1 {
          def [result1, s2] := action1.run(s1)
          func(result1).run(s2)
        }
      }
      to value(v) {
        return fn s { [v, s] }
      }
      to get() {
        return fn s { [s, s] }
      }
      to put(newS) {
        return fn oldS { [null, newS] }
      }
    }
    
    ? stateM.then(stateM.then(stateM.get(), fn v { stateM.put(v + 1) }),
    >             fn _ { stateM.value("bye") }).run(99)
    # value: ["bye", 100]
*)

(* state monad in Emily *)
(* type 'result 'state action = 'state -> 'result * 'state
   type monadicF???
   type 'result 'state valueDoer = 'result -> ('state -> 'result * 'state)
   type 'state getter = unit -> ('state -> 'state * 'state)
   type 'state putter = 'state -> ('state -> 'state option * 'state
*)
(*
module stateMonad = struct

    let doThen action1 monadicF = newF state1 -> 
        let (result1, state2) = action1 state1 in
        f result1 state2
        
    let doValue v = fun s -> (v, s)
    
    let get () -> fun s -> (s, s)
    
    let put newS = fun oldS -> ((), newS) 
    
end

*)  

(*
module type WorkersSig = sig

    type workManager
    
    (* given a numvats and a function to put in all the vats create a WorkManager *)
    val make : int -> Far.funcS ->  -> workManager
    
    (* given a queue of argument-sets for the workManager's function, and a base 
        value to start the accumulation and anaccumulator function to collect 
        results, return a vow for the computation result *)
    val compute : workManager -> Far.sendable list -> 'a -> 
        ('a -> Far.sendable -> 'a)  -> 'a vow

    (* eliminate this workManager, i.e., kill all the vats, after all 
        queued computations have been completed. An excellent solution 
        would have termination automatic as part of postmortem finalization *)
    val terminate: workManager -> unit
end
module Workers:WorkersSig = struct
    
end
*) 
        
  
