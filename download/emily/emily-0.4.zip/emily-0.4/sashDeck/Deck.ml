(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

		type t = {mutable nexti : int; cards : int array; randGen : Randomizer.t }

		let make () = 
            let newRand = Randomizer.make 18 in
			let newDeck = {nexti = 0; cards = Array.make 52 53; randGen = newRand} in
    		for i = 0 to 51 do
        		newDeck.cards.(i) <- i+1;
    		done;
    		newDeck

		let next deck = 
			let card = deck.cards.(deck.nexti) in
    		deck.nexti <- deck.nexti + 1;
    		card
    
		let shuffle deck =        
           for i = 0 to 51 do 
            	let j = (Randomizer.next deck.randGen) mod 52 in
                let temp = deck.cards.(i) in
                deck.cards.(i) <- deck.cards.(j);
                deck.cards.(j) <- temp;                  
            done;
            deck.nexti <- 0 
