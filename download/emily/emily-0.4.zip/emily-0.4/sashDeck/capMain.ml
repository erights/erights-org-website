(* Copyright 2007 Hewlett-Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)

open SashInterface

let vatFuncs i = fun (blah:Far.sendable) -> Far.Unit 

let start endowments auths = 
	match auths with 
	SashInterface.Str runsToMake :: SashInterface.Time clock :: [] ->
		let runs = int_of_string runsToMake in
		let firstOnes = ref 0 in
		endowments.userOut "Starting shuffles";
		let starttime = clock() in
		for i = 1 to runs do
			let deck = Deck.make () in
			for j = 1 to runs do
			    Deck.shuffle deck;
			    if (Deck.next deck = 1) then firstOnes := !firstOnes + 1
			done
		done;
		let endtime = clock() in
		endowments.userOut ("Shuffle time: " ^ 
		    (string_of_float (endtime -. starttime)));
		endowments.userOut ("number of FirstOnes: " ^ (string_of_int !firstOnes)); 0
	| _ -> endowments.userOut 
	    "Need a number of runs and a clock for deck shuffler"; 1
