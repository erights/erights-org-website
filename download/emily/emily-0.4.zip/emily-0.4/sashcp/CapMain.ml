
(* Copyright 2007 Hewlett Packard under the terms of the MIT X license
   found at http://www.opensource.org/licenses/mit-license.html  *)
   

(****** CapMain for cp readablefile editablefile ************)


open SashInterface
open MleFile
open Kit  

let vatFuncs i = 
    let dummy (blah:Far.sendable) = Far.Unit in dummy
    
let start endowments authlist = 
	match authlist with 
	| Readable fromFile :: Editable outFile :: []  -> 
	    fromFile.getBytes() >. outFile.setBytes; 0
	| _ -> endowments.SashInterface.userOut 
	    "To use cp, an input file and output file are required"; 1
	    
  
   
	
