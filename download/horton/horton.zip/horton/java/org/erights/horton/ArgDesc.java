// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import java.io.Serializable;
import java.lang.reflect.Method;

import org.joe_e.array.ConstArray;
import org.joe_e.Struct;
import org.ref_send.Record;


/**
 * Describes an encoding of a sent value, to the decoded by the receiver's
 * handler ({@link Deliverator} or Proxy) into the value to be delivered. 
 * <p>
 * As sent in the argsDesc list of a {@link 
 * Deliverator#deliver(Method, ConstArray) deliver/2} message, this is the
 * Delegator's Introducer's Proxy's description of an argument sent by the
 * Introducer. It is to be decoded by the Recipient's Acceptor's Deliverator
 * into a value to the delivered as the corresponding argument of the
 * message to the delivered to the Acceptor.
 * <p>
 * When revealed as the result of a deliver/2, this is the Recipient's 
 * Acceptor's Deliverator's description of the result of the message delivered
 * to the Acceptor. It is to be decoded by the Recipient's Acceptor's 
 * Deliverator into a value to be revealed to the Introducer as the result of
 * the message sent by the Introducer.
 * <p>
 * Most explanations use terminology appropriate to the argument-passing case,
 * leaving the result-revealing case as an exercise for the reader.
 * 
 * @author Mark S. Miller
 */
public abstract class 
ArgDesc extends Struct implements Record, Serializable {
    static private final long serialVersionUID = 1L;
}
