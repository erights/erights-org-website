// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import org.joe_e.array.ConstArray;
import org.ref_send.Record;
import org.ref_send.deserializer;
import org.ref_send.name;
import org.ref_send.promise.Promise;


/**
 * Used to represent the passing-by-copy of a {@link Record}.
 * 
 * @author Mark S. Miller
 */
public final class ArgDescList extends ArgDesc {
    private static final long serialVersionUID = 1L;

    public final Class arrayClass;
    public final ConstArray<Promise<ArgDesc>> descs;
    
    @deserializer
    public 
    ArgDescList(@name("arrayClass") final Class arrayClass,
                @name("descs") final ConstArray<Promise<ArgDesc>> descs) {
        this.arrayClass = arrayClass;
        this.descs = descs;
    }
}
