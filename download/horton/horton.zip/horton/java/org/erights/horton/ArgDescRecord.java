// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import java.lang.reflect.Field;

import org.joe_e.array.ConstArray;
import org.ref_send.Record;
import org.ref_send.deserializer;
import org.ref_send.name;
import org.ref_send.promise.Promise;


/**
 * Used to represent the passing-by-copy of a {@link Record}.
 * 
 * @author Mark S. Miller
 */
public final class ArgDescRecord extends ArgDesc {
    private static final long serialVersionUID = 1L;

    public final Class recordClass;
    public final ConstArray<Field> fields;
    public final ConstArray<Promise<ArgDesc>> descs;
    
    @deserializer
    public 
    ArgDescRecord(@name("recordClass") final Class recordClass, 
                  @name("fields") final ConstArray<Field> fields,
                  @name("descs") final ConstArray<Promise<ArgDesc>> descs) {
        this.recordClass = recordClass;
        this.fields = fields;
        this.descs = descs;
    }
}
