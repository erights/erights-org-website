// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import org.joe_e.array.ConstArray;
import org.ref_send.deserializer;
import org.ref_send.name;


/**
 * Describes the responsibility-tracked delegation of access to a Power.
 * 
 * @author Mark S. Miller
 */
public final class 
ArgDescTracked extends ArgDesc {
    private static final long serialVersionUID = 1L;

    /**
     * Identifies which party the Delegator recommends the Recipient holds
     * responsible for the behavior of the Power accessed via oWhat.
     */
    public final Who issuerWho;
    
    /**
     * The Delegator's explanation to the Recipient as to how it recommends
     * the Recipient regard the Issuer. 
     * <p>
     * Also explains to the Recipient why the Delegator is giving it access to 
     * this Power.
     * XXX Consider removing the whyAccept field
     */
    public final Why whyAccept;
    
    /**
     * An Opaque wrapping a What wrapping a Deliverator for this Power.
     * <p>
     * The Opaque should only be unsealable by the party this Deliverator knows
     * to hold responsible for the resulting accesses. The What's 
     * {@link What#provide(Opaque) provide/1} method will only unseal its
     * argument if it sealed by its Issuer's Who, which should be the same as
     * {@link #issuerWho}. If these are not the same, then this protocol fails
     * to give access, as it should.
     */
    public final WhatBox oWhat;
    
    /**
     * The list of interface types that the proxy should implement.
     */
    public final ConstArray<Class> proxyTypes;

    @deserializer
    public 
    ArgDescTracked(@name("issuerWho")  final Who issuerWho, 
                   @name("whyAccept")  final Why whyAccept, 
                   @name("oWhat")      final WhatBox oWhat,
                   @name("proxyTypes") final ConstArray<Class> proxyTypes) {
        this.issuerWho = issuerWho;
        this.whyAccept = whyAccept;
        this.oWhat = oWhat;
        this.proxyTypes = proxyTypes;
    }
}
