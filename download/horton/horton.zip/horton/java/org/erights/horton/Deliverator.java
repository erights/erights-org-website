// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import java.lang.reflect.Method;

import org.joe_e.array.ConstArray;
import org.ref_send.promise.Promise;


/**
 * A remotable interface representing an exported, responsibility-tracked 
 * reference.
 * 
 * @author Mark S. Miller
 */
public interface 
Deliverator {

    /**
     * Like {@link #deliver(Method, ConstArray) deliver/2}, but with no
     * result.
     */
    void
    deliverOnly(Method verb, ConstArray<Promise<ArgDesc>> argDescs) 
    throws Exception;

    /**
     * As the Recipient's Acceptor's Deliverator, invoke the Acceptor's
     * verb method with the described arguments, revealing a description of 
     * the result.
     * 
     * @param verb The method of the Acceptor to invoke.
     * @param argDescs Descriptions of the arguments, to be decoded to obtain
     *                 the actual arguments to use.
     * @return A promise for a description of the result of delivering the
     *         described message.
     * @throws Exception 
     */
    Promise<ArgDesc>
    deliver(Method verb, ConstArray<Promise<ArgDesc>> argDescs) 
    throws Exception;

    /**
     * As the Issuer's Power's Deliverator, return something (only) the stated
     * Recipient can use to access this same Power.
     * 
     * @param recipientWho The identity the Issuer should hold responsible for 
     *                     accesses to the Power made via the result. 
     * @param whyIssue Explains to the Issuer how the Delegator recommends the
     *            Issuer regard the Recipient.
     * @return An {@link Opaque} that only the identified recipient can unseal
     *         to obtain the {@link What} that will provide the new 
     *         Deliverator.
     */
    WhatBox
    intro(Who recipientWho, Why whyIssue);
}
