// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton;

import org.ref_send.promise.eventual.Resolver;

/**
 * A remotable wrapper of a {@link Resolver}&lt;{@link Deliverator}&gt;, as 
 * created by a {@link Who}, such that only the responsible party indentified 
 * by that Who can unseal the Box.
 * <p>
 * It's called a DeliveratorHoleBox since a Resolver&lt;Deliverator&gt; is
 * effectively a Deliverator-shaped hole that needs to be filled in with a
 * Deliverator.
 * 
 * @author Mark S. Miller
 */
public interface DeliveratorHoleBox {

}
