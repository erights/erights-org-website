// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton;

import org.joe_e.Powerless;


public class 
UnknownArgDescException extends RuntimeException implements Powerless {
    private static final long serialVersionUID = 1L;

    public UnknownArgDescException(String message) {
        super(message);
    }
}
