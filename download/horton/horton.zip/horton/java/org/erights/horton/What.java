// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

/**
 * Provides access to its Issuer's Power's Deliverator.
 * 
 * @author Mark S. Miller
 */
public interface 
What {

    /**
     * As the Issuer's Power's Deliverator's What for the Recipient, unseal
     * the oResDel and resolve the contained Resolver to my Deliverator.
     * 
     * @param oResDel A Resolver created and by the Recipient, and sealed
     *                by the Recipient using the Issuer's Who, so that
     *                the Issuer can unseal it and resolve this Resolver
     *                to this Power. 
     */
    void
    provide(DeliveratorHoleBox oResDel);
}
