// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton;

/**
 * A remotable wrapper of a {@link What}, as created by a {@link Who}, such 
 * that only the responsible party indentified by that Who can unseal the Box.
 * 
 * @author Mark S. Miller
 */
public interface WhatBox {

}
