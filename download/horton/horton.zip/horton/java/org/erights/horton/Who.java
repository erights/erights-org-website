// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import org.ref_send.Brand;
import org.ref_send.cacheable;
import org.ref_send.promise.Promise;
import org.ref_send.promise.eventual.Resolver;


/**
 * Represents a responsible identity, identifying a responsible party.
 * <p>
 * This serves the role often played by a public key in various cryptographic
 * protocols, identifying the party that knows and can employ the corresponding
 * private key. Indeed, an implementation of a Who may well wrap a public
 * encryption key. The {@link Opaque}s resulting from the seal method
 * are assumed to only be unsealable by the identified party.
 * <p>
 * By design, Horton does not imply any cryptographic non-repudiation. 
 * Therefore, the Who corresponds to a public encryption key, where only the
 * ability to unseal is kept private. An alternate Horton-like protocol is
 * possible, in which the Who provides only unseal ability -- acting like a
 * public signature verification key, where the ability to seal is kept 
 * private. The design of a Horton with non-repudiation is left as an exercise
 * for the reader.
 * 
 * @author Mark S. Miller
 */
public interface 
Who {

    /**
     * A self-chosen name, as in the "nickname" of Zooko's triangle.
     * 
     * @see Brand#label
     */
    @cacheable Promise<String>
    getLabel();

    /**
     * Creates a sealed Opaque that only the party identified by this Who can
     * unseal to obtain the payload.
     */
    WhatBox 
    sealWhat(What payload);
    
    /**
     * Creates a sealed Opaque that only the party identified by this Who can
     * unseal to obtain the payload.
     */
    DeliveratorHoleBox
    sealCD(Resolver<Deliverator> payload);
}
