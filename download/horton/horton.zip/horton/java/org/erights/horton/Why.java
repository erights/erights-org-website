// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton;

import java.io.Serializable;

import org.joe_e.Struct;
import org.ref_send.Record;


/**
 * An explanation by the Delegator to one party, recommending how it regard
 * another party, and why it is being connected to some particular object
 * whose behavior the other party should be held responsible for. 
 * 
 * @author Mark S. Miller
 */
public abstract class 
Why extends Struct implements Record, Serializable {
    static private final long serialVersionUID = 1L;

    /**
     * To what degree does the sender volunteer to be held responsible by the 
     * receiver for the behavior of the other party?
     * <p>
     * The number should be 0..100, indicating the percentage of the
     * sender's reputation with the receiver it is willing to place at risk
     * to the other party's misbehavior.  
     * <p>
     * As sent by the Delegator's Introducer's Proxy to the Issuer's Power's
     * Deliverator for the Delegator, this states the degree the Delegator 
     * volunteers to assume responsibility for providing the Recipient's 
     * Acceptor with access to the Issuer's Power. A default Delegator 
     * behavior should be to assume 100% responsibility. A default Issuer 
     * behavior should be to deny the Power to the Recipient unless the 
     * Delegator assumes at least 1% responsibility.
     * <p>
     * As sent by the Delegator's Introducer's Proxy in a 
     * {@link ArgDescTracked} to the Recipient's Acceptor's Deliverator for
     * the Delegator, this states the degree the Delegator volunteers to 
     * assume responsibility for the proper functioning of the Power. A 
     * default Delegator behavior should be to assume 0% responsibility for
     * the Power's behavior. A default Recipient behavior should be to ignore 
     * this flag.
     */
    public final int blameQuotaPercent;

    // Since this class is abstract, it doesn't make sense to declare its
    // constructor to be a deserializer. However, since it is a Record,
    // the constructors of all concrete subclasses should be deserializers.
    protected 
    Why(final int blameQuotaPercent) {
        this.blameQuotaPercent = blameQuotaPercent;
    }
}
