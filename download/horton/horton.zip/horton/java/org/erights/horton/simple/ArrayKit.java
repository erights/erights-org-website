// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import org.joe_e.array.ConstArray;


/**
 * @author Mark S. Miller
 */
public final class ArrayKit {
    
    private ArrayKit() {}

    /**
     * 
     * 
     * @param <D> The domain type, i.e., the type that func accepts as
     *            input.
     * @param <R> The range type, i.e., the type that func produces.
     * @param result The result argument is supplied explicitly in order to 
     *               overcome type erasure. It must be the same size as arr.
     * @param arr The input
     * @param func The function to be applied to each element of arr.
     * @throws Exception
     */
    static public <D,R> void
    map(R[] result, ConstArray<D> arr, Func<D,R> func) throws Exception {
        int len = arr.length();
        if (len != result.length) {
            throw new RuntimeException("not same length");
        }
        for (int i = 0; i < len; i++) {
            result[i] = func.post(arr.get(i));
        }
    }
    
    static public <D> D 
    the(ConstArray<D> arr, Func<D,Boolean> pred) throws Exception {
        D result = null;
        boolean hasResult = false;
        int len = arr.length();
        for (int i = 0; i < len; i++) {
            if (pred.post(arr.get(i))) {
                if (hasResult) {
                    throw new RuntimeException("too many answers");
                } else {
                    result = arr.get(i);
                    hasResult = true;
                }
            }
        }
        if (hasResult) {
            return result;
        } else {
            throw new RuntimeException("answer not found");
        }
    }
}
