// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import static org.erights.horton.simple.ArrayKit.map;
import static org.erights.horton.simple.ArrayKit.the;
import static org.joe_e.array.ConstArray.list;
import static org.ref_send.promise.Resolved.ref;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.erights.horton.ArgDesc;
import org.erights.horton.ArgDescList;
import org.erights.horton.ArgDescRecord;
import org.erights.horton.ArgDescSimple;
import org.erights.horton.ArgDescTracked;
import org.erights.horton.Deliverator;
import org.erights.horton.SimpleWhy;
import org.erights.horton.UnknownArgDescException;
import org.erights.horton.What;
import org.erights.horton.WhatBox;
import org.erights.horton.Who;
import org.erights.horton.Why;
import org.joe_e.array.ConstArray;
import org.joe_e.Powerless;
import org.joe_e.reflection.Deflection;
import org.joe_e.reflection.Reflection;
import org.ref_send.Record;
import org.ref_send.deserializer;
import org.ref_send.name;
import org.ref_send.promise.Promise;
import org.ref_send.promise.Rejected;
import org.ref_send.promise.eventual.Channel;
import org.ref_send.promise.eventual.Do;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public class 
BaseSentry extends Sentry {
    private static final long serialVersionUID = 1L;

    /**
     * @param _
     * @param me
     * @param who
     * @param targetWho
     */
    public BaseSentry(Eventual _, Be me, Who who, Who targetWho) {
        super(_, me, who, targetWho);
    }

    @SuppressWarnings("unchecked")
    protected Promise<ArgDesc> 
    encode(Object arg) throws Exception {
        if (null == arg) { return null; }
        // XXX BUG What if arg is an unresolved promise?
        // XXX BUG What if arg is a resolved promise?
        if (arg instanceof Powerless) {
            // Since all scalar arrays are Powerless, this works around
            // the fact that the default encodeList doesn't work for the 
            // scalar arrays.
            return ref(encodeDefault(arg));
        }
        HandlerX optHandlerX = optAmplifyProxy(arg);
        if (null != optHandlerX) {
            ConstArray<Class> proxyTypes = getProxyTypes(arg);
            if (optHandlerX.mySentry.myTargetWho_.equals(myTargetWho_)) {
                // XXX need encode2Proxy case
            }
            return ref(encode3Proxy(optHandlerX.mySentry, 
                                    optHandlerX.myDeliverator_,
                                    proxyTypes));
        }
        if (arg instanceof ConstArray) {
            return ref(encodeList((ConstArray<Object>)arg));
        }
        if (arg instanceof Record) {
            return ref(encodeRecord((Record)arg));
        }
        // XXX other cases needed!!
        return ref(encodeDefault(arg));
    }

    protected ArgDesc 
    encode3Proxy(Sentry sentry, 
                 Deliverator deliverator_, 
                 ConstArray<Class> proxyTypes) {
        Why whyIssue = getWhyIssue(sentry, deliverator_);
        Why whyAccept = getWhyAccept(sentry, deliverator_);
        WhatBox oWhat_ = deliverator_.intro(myTargetWho_, whyIssue);
        return new ArgDescTracked(sentry.myTargetWho_,
                                  whyAccept,
                                  oWhat_,
                                  proxyTypes);
    }

    protected Why getWhyIssue(Sentry sentry, Deliverator deliverator_) {
        return SimpleWhy.BECAUSE;
    }

    protected Why getWhyAccept(Sentry sentry, Deliverator deliverator_) {
        return SimpleWhy.WHY_NOT;
    }

    /**
     * The default implementation here does not (yet?) work for scalar arrays,
     * but that's mostly ok, since the default encode invokes encodeDefault
     * if the arg is Powerless.
     * @throws Exception 
     */
    @SuppressWarnings("unchecked")
    protected ArgDesc encodeList(ConstArray<Object> array) throws Exception {
        Promise<ArgDesc>[] argDescs = new Promise[array.length()];
        map(argDescs, array, new Func<Object,Promise<ArgDesc>>() {
            public Promise<ArgDesc> 
            post(Object arg) throws Exception { return encode(arg); }
        });
        return new ArgDescList(array.getClass(), list(argDescs));
    }

    @SuppressWarnings("unchecked")
    protected ArgDesc encodeRecord(final Record record) throws Exception {
        Class clazz = record.getClass();
        // XXX instance fields only
        ConstArray<Field> fields = Reflection.fields(clazz);
        Promise<ArgDesc>[] fieldDescs = new Promise[fields.length()];
        map(fieldDescs, fields, new Func<Field,Promise<ArgDesc>>() {
            public Promise<ArgDesc> 
            post(Field field) throws Exception {
                return encode(Deflection.get(field, record));
            }
        });
        return new ArgDescRecord(clazz, fields, list(fieldDescs));
    }

    protected ArgDesc 
    encodeDefault(Object arg) {
        return new ArgDescSimple(arg);
    }

    public Object 
    decode(Promise<ArgDesc> argDescPromise) throws Exception {
        if (null == argDescPromise) { return null; }
        ArgDesc argDesc;
        try {
            argDesc = argDescPromise.cast();
        } catch (Exception ex) {
            Object result = _.when(argDescPromise, new Do<ArgDesc,Object>() {
                public Object 
                resolve(ArgDesc ad) throws Exception {
                    return decodeArgDesc(ad);
                }
            });
            return result;
        }
        return decodeArgDesc(argDesc);
    }
    
    protected Object
    decodeArgDesc(ArgDesc argDesc) throws Exception {
        if (argDesc instanceof ArgDescSimple) {
            return decodeSimple((ArgDescSimple)argDesc);
        }
        if (argDesc instanceof ArgDescTracked) {
            return decodeTracked((ArgDescTracked)argDesc);
        }
        if (argDesc instanceof ArgDescList) {
            return decodeList((ArgDescList)argDesc);
        }
        if (argDesc instanceof ArgDescRecord) {
            return decodeRecord((ArgDescRecord)argDesc);
        }
        return decodeDefault(argDesc);
    }

    protected Object 
    decodeSimple(ArgDescSimple simple) {
        return simple.arg;
    }

    @SuppressWarnings("unchecked")
    protected Object 
    decodeTracked(final ArgDescTracked tracked) throws Exception {
        Who issuerWho_ = _._(tracked.issuerWho);
        Why whyAccept = tracked.whyAccept;
        final Class[] pTypes = new Class[tracked.proxyTypes.length()];
        tracked.proxyTypes.toArray(pTypes);
        What what_ = _.when(tracked.oWhat, new Do<WhatBox,What>() {
            public What 
            resolve(WhatBox oWhat) throws Exception {
                return me.unsealWhat(oWhat);
            }
        });
        Channel<Deliverator> chan = _.defer();
        what_.provide(issuerWho_.sealCD(chan.resolver));
        final Deliverator deliverator_ = _.cast(Deliverator.class,
                                                chan.promise);
        Promise<Sentry> proxySentryP = getProxySentry(issuerWho_, whyAccept);
        Object result = _.when(proxySentryP, new Do<Sentry,Object>() {
            public Object 
            resolve(Sentry proxySentry) throws Exception {
                InvocationHandler handler = 
                    new HandlerX(_, proxySentry, deliverator_);
                return Deflection.proxy(handler, pTypes);
            }
        });
        if (result instanceof InvocationHandler) {
            InvocationHandler h2 = (InvocationHandler)result;
            return Deflection.proxy(h2, pTypes);
        } else {
            return result;
        }
    }

    protected Object decodeList(ArgDescList adl) throws Exception {
        final Object[] NO_ARGS = {};
        final Method LIST_VERB = Reflection.method(adl.arrayClass, 
                                                   "list", 
                                                   NO_ARGS.getClass());
        int len = adl.descs.length();
        Object[] args = new Object[len];
        for (int i = 0; i < len; i++) {
            args[i] = decode(adl.descs.get(i));
        }
        try {
            return Deflection.invoke(LIST_VERB, null, args);
        } catch (Exception ex) {
            return new Rejected(ex);
        }
    }

    protected Object decodeRecord(final ArgDescRecord adr) throws Exception {
        ConstArray<Constructor> cs = Reflection.constructors(adr.recordClass);
        Constructor deser = the(cs,
                                new Func<Constructor,Boolean>() {
            public Boolean 
            post(Constructor constr) throws Exception {
                return constr.isAnnotationPresent(deserializer.class);
            }
        });
        final Annotation[][] paramsNotes = deser.getParameterAnnotations();
        Object[] args = new Object[paramsNotes.length]; 
        map(args, list(paramsNotes), new Func<Annotation[],Object>() {
            public Object 
            post(Annotation[] oneParamNotes) throws Exception {
                name nm = (name)the(list(oneParamNotes),
                                    new Func<Annotation,Boolean>() {
                    public Boolean 
                    post(Annotation arg) throws Exception {
                        return arg instanceof name;
                    }
                });
                final String fieldName = nm.value();
                int len = adr.fields.length();
                for (int i = 0; i < len; i++) {
                    if (fieldName.equals(adr.fields.get(i).getName())) {
                        return decode(adr.descs.get(i));
                    }
                }
                throw new RuntimeException("not found");
            }
        });
        return Deflection.construct(deser, args);
    }

    protected Object 
    decodeDefault(ArgDesc argDesc) {
        throw new UnknownArgDescException(argDesc.getClass().getName());
    }
    
    protected Promise<Sentry> 
    getProxySentry(Who issuerWho, Why whyAccept) throws Exception {
        // Ignore whyAccept.blameMe by default
        Sentry result = new BaseSentry(_, me, myWho, issuerWho);
        return ref(result);
    }

    protected Promise<Sentry> 
    getDeliveratorSentry(Who receiverWho, Why whyIssue) throws Exception {
        if (whyIssue.blameQuotaPercent <= 0) {
            throw new RuntimeException("Irresponsible");
        }
        Sentry result = new BaseSentry(_, me, myWho, receiverWho);
        return ref(result);
    }
}
