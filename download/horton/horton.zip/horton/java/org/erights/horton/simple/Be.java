// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import java.io.Serializable;

import org.erights.horton.Deliverator;
import org.erights.horton.DeliveratorHoleBox;
import org.erights.horton.What;
import org.erights.horton.WhatBox;
import org.joe_e.Token;
import org.ref_send.promise.eventual.Resolver;


/**
 * A holder of this gets to be an object identified by the corresponding 
 * Who.
 * 
 * @author Mark S. Miller
 */
public final class 
Be extends Token implements Serializable {
    private static final long serialVersionUID = 1L;

    What 
    unsealWhat(WhatBox opaque) {
        if (opaque instanceof WhatBoxX) {
            WhatBoxX opq = (WhatBoxX)opaque;
            if (this == opq.me) {
                return opq.myPayload;
            }
        }
        throw new ClassCastException("unrecognized WhatBox");
    }
    
    Resolver<Deliverator> 
    unsealCD(DeliveratorHoleBox opaque) {
        if (opaque instanceof DeliveratorHoleBox) {
            DeliveratorHoleBoxX opq = (DeliveratorHoleBoxX)opaque;
            if (this == opq.me) {
                return opq.myPayload;
            }
        }
        throw new ClassCastException("unrecognized DeliveratorHoleBox");
    }
}
