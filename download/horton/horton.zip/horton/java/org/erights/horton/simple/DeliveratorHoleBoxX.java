// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import org.erights.horton.Deliverator;
import org.erights.horton.DeliveratorHoleBox;
import org.ref_send.promise.eventual.Resolver;


/**
 * @author Mark S. Miller
 */
public class DeliveratorHoleBoxX implements DeliveratorHoleBox {

    final Be me;
    final Resolver<Deliverator> myPayload;
    
    
    DeliveratorHoleBoxX(final Be me, 
                        final Resolver<Deliverator> payload) {
        this.me = me;
        myPayload = payload;
    }
}
