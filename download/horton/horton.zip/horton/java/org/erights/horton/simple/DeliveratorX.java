// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton.simple;

import java.io.Serializable;
import java.lang.reflect.Method;

import org.erights.horton.ArgDesc;
import org.erights.horton.Deliverator;
import org.erights.horton.WhatBox;
import org.erights.horton.Who;
import org.erights.horton.Why;
import org.joe_e.array.ConstArray;
import org.ref_send.promise.Promise;


/**
 * @author Mark S. Miller
 */
public final class 
DeliveratorX implements Deliverator, Serializable {
    private static final long serialVersionUID = 1L;
    
    final Sentry mySentry;
    final Object myTarget;
    
    /**
     * @param sentry
     * @param target
     */
    public 
    DeliveratorX(Sentry sentry, Object target) {
        mySentry = sentry;
        myTarget = target;
    }

    public void 
    deliverOnly(Method verb, 
                ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        mySentry.callOnly(myTarget, verb, argDescs);
    }

    public Promise<ArgDesc> 
    deliver(Method verb, 
            ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        return mySentry.call(myTarget, verb, argDescs);
    }

    public WhatBox
    intro(Who recipientWho, Why whyIssue) {
        return mySentry.intro(recipientWho, whyIssue, myTarget);
    }
}
