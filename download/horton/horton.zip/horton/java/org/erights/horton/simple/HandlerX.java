// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton.simple;

import static org.joe_e.array.ConstArray.list;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.erights.horton.ArgDesc;
import org.erights.horton.Deliverator;
import org.ref_send.promise.Promise;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public final class 
HandlerX implements InvocationHandler, Serializable {
    private static final long serialVersionUID = 1L;
    
    final Sentry mySentry;
    final Deliverator myDeliverator_;

    public 
    HandlerX(final Eventual _,
             final Sentry sentry,
             final Deliverator deliverator) {
        mySentry = sentry;
        myDeliverator_ = _._(deliverator);
    }

    @SuppressWarnings("unchecked")
    public Object 
    invoke(Object proxy, Method verb, Object[] args) throws Exception {
        if (null == args) {
            args = new Object[0];
        }
        Promise<ArgDesc>[] argDescs = new Promise[args.length];
        for (int i = 0, max = args.length; i < max; i++) {
            argDescs[i] = mySentry.encode(args[i]);
        }
        if (Void.class == verb.getReturnType() ||
                void.class == verb.getReturnType()) {
            mySentry.deliverOnly(myDeliverator_, verb, list(argDescs));
            return null;
        } else {
            Promise<ArgDesc> result =
                mySentry.deliver(myDeliverator_, verb, list(argDescs));
            return mySentry.decode(result);
        }
    }
}
