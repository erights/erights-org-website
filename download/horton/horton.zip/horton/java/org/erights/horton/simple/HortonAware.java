// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import java.lang.reflect.Method;

import org.erights.horton.Who;


/**
 * If a Horton-aware application object that implements this interface, its
 * deliverators should invoke its {@link #invoke(Method, Object[], Who)} 
 * method, passing in the Who identifying who to blame for sending this 
 * message.
 * <p>
 * For example, a ScoopfsMail inbox should be Horton aware, and verify that
 * an incoming email message has as a From field the inbox corresponding
 * to whoBlame. A HortonAware object can depend on whoBlame being honest
 * iff only its own honest deliverators ever have access to it.
 * 
 * @author Mark S. Miller
 */
public interface HortonAware {

    /**
     * 
     */
    Object invoke(Method verb, Object[] args, Who whoBlame);
}
