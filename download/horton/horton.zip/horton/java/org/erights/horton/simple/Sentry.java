// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import static org.joe_e.array.ConstArray.list;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;

import org.erights.horton.ArgDesc;
import org.erights.horton.Deliverator;
import org.erights.horton.What;
import org.erights.horton.WhatBox;
import org.erights.horton.Who;
import org.erights.horton.Why;
import org.joe_e.array.ConstArray;
import org.joe_e.reflection.Deflection;
import org.ref_send.promise.Promise;
import org.ref_send.promise.Rejected;
import org.ref_send.promise.Volatile;
import org.ref_send.promise.eventual.Do;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public abstract class 
Sentry implements Serializable {
    private static final long serialVersionUID = 1L;

    protected final Eventual _;
    protected final Be me;
    protected final Who myWho;
    protected final Who myTargetWho_;

    /**
     * @param _
     * @param me
     * @param who
     * @param targetWho_
     */
    protected Sentry(final Eventual _, 
                     final Be me, 
                     final Who who, 
                     final Who targetWho) {
        this._ = _;
        this.me = me;
        myWho = who;
        myTargetWho_ = _._(targetWho);
    }

    protected abstract Promise<ArgDesc> 
    encode(Object arg) throws Exception;
    
    public abstract Object 
    decode(Promise<ArgDesc> argDescPromise) throws Exception;
    
    /**
     * Rights amplification, for use by subclasses.
     * <p>
     * If <tt>possibleProxy</tt> is one of our {@link Proxy}s, i.e., is a 
     * Proxy on a {@link HandlerX} who's Sentry's me is the same as my me,
     * then return it. Otherwise return null.
     */
    protected final HandlerX
    optAmplifyProxy(Object possibleProxy) throws Exception {
//      if (!Proxy.isProxyClass(possibleProxy.getClass())) {
        if (!(possibleProxy instanceof Proxy)) {
            return null;
        }
        // XXX For speed, may want to isProxyClass
        InvocationHandler h1;
        while (true) {
            try {
                h1 = Deflection.peel((Proxy)possibleProxy);
            } catch (Exception ex) {
                return null;
            }
            if (!(h1 instanceof Volatile)) {
                break;
            }
            try {
                possibleProxy = ((Volatile)h1).cast();
            } catch (Exception ex) {
                return null;
            }
        }
        if (h1 instanceof HandlerX) {
            HandlerX handlerX = (HandlerX)h1;
            if (handlerX.mySentry.me == me) {
                return handlerX;
            }
        }
        return null;
    }

    protected abstract Promise<Sentry> 
    getProxySentry(Who issuerWho, Why whyAccept) throws Exception;

    protected abstract Promise<Sentry> 
    getDeliveratorSentry(Who recipientWho, Why whyIssue) throws Exception;

    protected void 
    deliverOnly(Deliverator deliverator_, 
                Method verb, 
                ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        deliverator_.deliverOnly(verb, argDescs);
    }

    protected Promise<ArgDesc> 
    deliver(Deliverator deliverator_, 
            Method verb, 
            ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        return deliverator_.deliver(verb, argDescs);
    }

    protected void 
    callOnly(Object target, 
             Method verb, 
             ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        Object[] args = new Object[argDescs.length()];
        for (int i = 0, max = args.length; i < max; i++) {
            args[i] = decode(argDescs.get(i));
        }
        invoke(target, verb, args);
    }

    protected Promise<ArgDesc> 
    call(Object target, 
         Method verb, 
         ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        
        Object[] args = new Object[argDescs.length()];
        for (int i = 0, max = args.length; i < max; i++) {
            args[i] = decode(argDescs.get(i));
        }
        Object result;
        try {
            result = invoke(target, verb, args);
        } catch (Exception ex) {
            return new Rejected<ArgDesc>(ex);
        }
        return encode(result);
    }

    protected Object 
    invoke(Object target, Method verb, Object[] args) throws Exception {
        if (target instanceof HortonAware) {
            HortonAware ha = (HortonAware)target;
            return ha.invoke(verb, args, myTargetWho_);
        } else {
            return Deflection.invoke(verb, target, args);
        }
    }

    public Who getWho() {
        return myWho;
    }

    public WhatBox intro(Who recipientWho, Why whyIssue, final Object target) {
        Who recipientWho_ = _._(recipientWho);
        Deliverator d_ = null;
        Promise<Sentry> newSentryP = null;
        try {
            newSentryP = getDeliveratorSentry(recipientWho, whyIssue);
        } catch (Exception ex) {
            d_ = _.cast(Deliverator.class, 
                        new Rejected<Deliverator>(ex));
        }
        if (null == d_) {
            d_ = _.when(newSentryP, new Do<Sentry,Deliverator>() {
                public Deliverator 
                resolve(Sentry newSentry) throws Exception {
                    return new DeliveratorX(newSentry, target);
                }
            });
        }
        What what = new WhatX(_, me, d_);
        return recipientWho_.sealWhat(what);
    }
    
    public ConstArray<Class> getProxyTypes(Object arg) {
        ArrayList<Class> proxyTypeList = new ArrayList<Class>();
        getProxyTypes(arg.getClass(), proxyTypeList);
        Class[] proxyClasses = new Class[proxyTypeList.size()];
        ConstArray<Class> proxyTypes = 
            list(proxyTypeList.toArray(proxyClasses));
        return proxyTypes;
    }
    
    protected void getProxyTypes(Class proxyClass, 
                                 ArrayList<Class> proxyTypeList) {
        for (Class intf : proxyClass.getInterfaces()) {
            if (Deflection.allowed(intf)) {
                proxyTypeList.add(intf);
            } else {
                getProxyTypes(intf, proxyTypeList);
            }
        }
    }
}
