// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple;

import org.erights.horton.What;
import org.erights.horton.WhatBox;


/**
 * @author Mark S. Miller
 */
final class WhatBoxX implements WhatBox {

    final Be me;
    final What myPayload;
    
    
    WhatBoxX(final Be me, final What payload) {
        this.me = me;
        myPayload = payload;
    }
}
