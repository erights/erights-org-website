// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton.simple;

import java.io.Serializable;

import org.erights.horton.Deliverator;
import org.erights.horton.DeliveratorHoleBox;
import org.erights.horton.What;
import org.ref_send.promise.eventual.Do;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
final class 
WhatX implements What, Serializable {
    private static final long serialVersionUID = 1L;
    
    private final Eventual _;
    private final Be me;
    private final Deliverator myDeliverator;

    WhatX(final Eventual _, final Be me, final Deliverator deliverator) {
        this._ = _;
        this.me = me;
        myDeliverator = deliverator;
    }

    public void 
    provide(DeliveratorHoleBox oResDel) {
        _.when(oResDel, new Do<DeliveratorHoleBox,Void>() {
            public Void 
            resolve(DeliveratorHoleBox arg) throws Exception {
                return _._(me.unsealCD(arg)).resolve(myDeliverator);
            }
        });
    }
}
