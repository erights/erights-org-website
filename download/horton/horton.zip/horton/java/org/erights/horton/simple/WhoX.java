// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............

package org.erights.horton.simple;

import static org.ref_send.promise.Resolved.ref;

import java.io.Serializable;

import org.erights.horton.Deliverator;
import org.erights.horton.DeliveratorHoleBox;
import org.erights.horton.What;
import org.erights.horton.WhatBox;
import org.erights.horton.Who;
import org.ref_send.promise.Promise;
import org.ref_send.promise.eventual.Resolver;


/**
 * @author Mark S. Miller
 */
public final class 
WhoX implements Who, Serializable {
    private static final long serialVersionUID = 1L;

    private final String myLabel;
    private final Be me;
    
    public WhoX(final String label, final Be me) {
        myLabel = label;
        this.me = me;
    }

    public Promise<String> 
    getLabel() {
        return ref(myLabel);
    }

    public WhatBox
    sealWhat(What payload) {
        return new WhatBoxX(me, payload);
    }

    public DeliveratorHoleBox
    sealCD(Resolver<Deliverator> payload) {
        return new DeliveratorHoleBoxX(me, payload);
    }
}
