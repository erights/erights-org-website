// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple.test;

import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public final class AliceX implements Alice {

    private final Bob myBob_;
    private final Carol myCarol_;

    public AliceX(final Eventual _, final Bob bob, final Carol carol) {
        myBob_ = _._(bob);
        myCarol_ = _._(carol);
    }
    
    public void doit() {
        myBob_.foo(myCarol_);
    }
}
