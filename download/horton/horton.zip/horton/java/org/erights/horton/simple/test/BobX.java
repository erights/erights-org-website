// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple.test;

import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public class BobX implements Bob {
    
    private final Eventual _; 

    public BobX(final Eventual _) {
        this._ = _;
    }

    public void foo(Carol carol) {
        Carol carol_ = _._(carol);
        carol_.hi();
    }

}
