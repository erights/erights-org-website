// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple.test;

import static org.ref_send.promise.Resolved.ref;

import java.io.Writer;

import org.erights.horton.ArgDesc;
import org.erights.horton.ArgDescTracked;
import org.erights.horton.SimpleWhy;
import org.erights.horton.WhatBox;
import org.erights.horton.Who;
import org.erights.horton.simple.Be;
import org.erights.horton.simple.Sentry;
import org.erights.horton.simple.WhoX;
import org.erights.sash.Plugin;
import org.erights.sash.QuoteWriter;
import org.erights.sash.SashPowerbox;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public final class HortonTester implements Plugin {
    
    static private Sentry
    makeAutoSentry(Eventual _, Writer userOut, String label) throws Exception {
        Be be = new Be();
        Who who = new WhoX(label, be);
        Writer quoter = QuoteWriter.nest(userOut, "\""+label+"\" says:");
        return new LoggingSentry(_, be, who, who, quoter, "auto:");
    }
    
    static private Object
    hortonRef(Eventual _,
              Object target,
              Sentry hostSentry,
              Sentry userSentry) throws Exception {
        Who host_ = _._(hostSentry.getWho());
        Who user_ = _._(userSentry.getWho());
        WhatBox oWhat = hostSentry.intro(user_, SimpleWhy.BECAUSE, target);
        ArgDesc adt = new ArgDescTracked(host_, 
                                         SimpleWhy.BECAUSE,
                                         oWhat,
                                         hostSentry.getProxyTypes(target));
        Object result = userSentry.decode(ref(adt));
        return result;
    }

    public void 
    start(Eventual _,
          SashPowerbox powerbox, 
          Object... auths) throws Exception {
        powerbox.println("Horton test started");
        final Writer userOut = powerbox.getUserOut().cast();
        
        Sentry sentryA = makeAutoSentry(_, userOut, "Adams");
        Sentry sentryB = makeAutoSentry(_, userOut, "Barker");
        Sentry sentryC = makeAutoSentry(_, userOut, "Connors");
        
        Bob bob = new BobX(_);
        Bob bob_ = (Bob)hortonRef(_, bob, sentryB, sentryA);
         
        Carol carol = new CarolX();
        Carol carol_ = (Carol)hortonRef(_, carol, sentryC, sentryA);
         
        Alice alice = new AliceX(_, bob_, carol_);
        alice.doit();
    }
}
