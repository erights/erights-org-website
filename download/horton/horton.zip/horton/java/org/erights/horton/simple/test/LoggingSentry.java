// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.horton.simple.test;

import static org.ref_send.promise.Resolved.ref;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;

import org.erights.horton.ArgDesc;
import org.erights.horton.Deliverator;
import org.erights.horton.Who;
import org.erights.horton.Why;
import org.erights.horton.simple.BaseSentry;
import org.erights.horton.simple.Be;
import org.erights.horton.simple.Sentry;
import org.erights.sash.QuoteWriter;
import org.joe_e.array.ConstArray;
import org.ref_send.promise.Promise;
import org.ref_send.promise.eventual.Do;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public final class LoggingSentry extends BaseSentry {
    private static final long serialVersionUID = 1L;
    
    private final Writer myBaseLog;
    private Writer myLog;

    public LoggingSentry(Eventual _, 
                         Be me, 
                         Who who, 
                         Who targetWho,
                         Writer baseLog,
                         String header) throws Exception {
        super(_, me, who, targetWho);
        myBaseLog = baseLog;
        myLog = QuoteWriter.nest(baseLog, header);
    }
    
    private void log(String str) throws IOException {
        myLog.write(str);
        myLog.flush();
    }

    protected Promise<Sentry> 
    getProxySentry(final Who issuerWho, 
                   Why whyAccept) throws Exception {
        // Ignore whyAccept.blameMe by default
        return _.when(issuerWho.getLabel(), 
                      new Do<String,Promise<Sentry>>() {
            public Promise<Sentry> 
            resolve(String iLabel) throws Exception {
                Sentry result = new LoggingSentry(_, 
                                                  me, 
                                                  myWho, 
                                                  issuerWho, 
                                                  myBaseLog,
                                                  "to "+iLabel+":");
                return ref(result);
            }
        });
    }

    protected Promise<Sentry> 
    getDeliveratorSentry(final Who receiverWho, 
                         Why whyIssue) throws Exception {
        if (whyIssue.blameQuotaPercent <= 0) {
            throw new RuntimeException("Irresponsible");
        }
        return _.when(receiverWho.getLabel(),
                      new Do<String,Promise<Sentry>>() {
            public Promise<Sentry> 
            resolve(String rLabel) throws Exception {
                Sentry result = new LoggingSentry(_, 
                                                  me, 
                                                  myWho, 
                                                  receiverWho, 
                                                  myBaseLog,
                                                  "from "+rLabel+":");
                return ref(result);
            }
        });
    }

    static private String describe(Method verb) {
        String className = verb.getDeclaringClass().getName();
        int lastDot = className.lastIndexOf('.');
        return className.substring(lastDot+1)+
        "#"+verb.getName()+
        "/"+verb.getParameterTypes().length;
    }

    protected Promise<ArgDesc> 
    deliver(Deliverator deliverator_, 
            Method verb, 
            ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        log("<- " + describe(verb));
        return super.deliver(deliverator_, verb, argDescs);
    }

    protected void 
    deliverOnly(Deliverator deliverator_, 
                Method verb, 
                ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        log("<- " + describe(verb));
        super.deliverOnly(deliverator_, verb, argDescs);
    }

    protected Promise<ArgDesc> 
    call(Object target,
         Method verb,
         ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        
        log(". " + describe(verb));
        return super.call(target, verb, argDescs);
    }

    protected void 
    callOnly(Object target, 
             Method verb, 
             ConstArray<Promise<ArgDesc>> argDescs) throws Exception {
        log(". " + describe(verb));
        super.callOnly(target, verb, argDescs);
    }
    
    
}
