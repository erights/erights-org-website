// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import org.joe_e.Token;


/**
 * Must not be made safe.
 * 
 * @author Mark S. Miller
 */
public final class MagicToken extends Token {
    private static final long serialVersionUID = 1L;

    /**
     * God-power token, must not be made public.
     */
    static final MagicToken THE_ONE = new MagicToken();
    
    /**
     * Must not be made public
     */
    private MagicToken() {}

    /**
     * Blows up if not provided with the authorizing magic token.
     */
    static public void check(MagicToken token) {
        if (THE_ONE != token) {
            throw new RuntimeException("need the magic token");
        }
    }
}
