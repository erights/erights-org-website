// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import java.io.Reader;

import org.joe_e.charset.UTF8;


/**
 * @author Mark S. Miller
 */
public final class Magic_stdin {

    static public Reader
    makeMagicPower(MagicToken token) {
        MagicToken.check(token);
        
        return UTF8.input(System.in);
    }
}
