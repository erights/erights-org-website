// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import org.joe_e.Token;
import org.ref_send.list.List;
import org.ref_send.promise.eventual.Eventual;
import org.ref_send.promise.eventual.Loop;
import org.ref_send.promise.eventual.Task;


/**
 * @author Mark S. Miller
 */
final class Q {

    private Q() {}
    
    static private final List<Task> work = List.list();
    
    static final Eventual _ = new Eventual(new Token(), new Loop<Task>() {
        public void
        run(final Task task) {
            work.append(task);
        }
    });

    static void start() throws Exception {
        while (!work.isEmpty()) {
            work.pop().run();
        }
    }
}
