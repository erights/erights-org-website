// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import java.io.IOException;
import java.io.Writer;


/**
 * Wraps a writer, in order to provide email quoting syntax
 * 
 * @author Mark S. Miller
 */
public final class QuoteWriter extends Writer {
    
    private Writer myOptBaseWriter;
    private final StringBuilder myBuffer;
    private final String myHeader;
    private int myColumn = 0;
    private final int myLimit;
    
    public 
    QuoteWriter(final Writer baseWriter, 
                final String header, 
                final int limit) {
        assert null != baseWriter;
        assert null != header;
        assert 1 <= header.length();
        assert -1 == header.indexOf('\n');
        assert 10 <= limit;
        myOptBaseWriter = baseWriter;
        myBuffer = new StringBuilder();
        myHeader = header;
        myLimit = limit;
    }
    
    static public Writer
    nest(final Writer baseWriter, final String header) {
        int limit;
        if (baseWriter instanceof QuoteWriter) {
            QuoteWriter quoter = (QuoteWriter)baseWriter;
//          XXX Math.max/2 isn't taming-enabled.
//          limit = Math.max(10, quoter.myLimit -2);
            limit = quoter.myLimit -2;
            if (limit < 10) { limit = 10; }
        } else {
            limit = 79;
        }
        return new QuoteWriter(baseWriter, header, limit);
    }
    
    public void 
    close() throws IOException {
        if (null != myOptBaseWriter) {
            flush();
            myOptBaseWriter.close();
            myOptBaseWriter = null;
        }
    }
    
    public void 
    flush() throws IOException {
        myOptBaseWriter.write(myBuffer.toString());
        myBuffer.setLength(0);
        if (1 <= myColumn && !(myOptBaseWriter instanceof QuoteWriter)) {
            myOptBaseWriter.write('\n');
        }
        myOptBaseWriter.flush();
        myColumn = 0;
    }

    private void 
    writeChars(char... cs) throws IOException {
        for (char c : cs) {
            myBuffer.append(c);
            if ('\n' == c) {
                myColumn = 0;
            } else {
                myColumn++;
            }
        }
    }
    
    private void 
    writeStr(String str) throws IOException {
        writeChars(str.toCharArray());
    }
    
    public void 
    write(final char[] cbuf, 
          final int off, 
          final int len) throws IOException {
        if (0 == myColumn) {
            myBuffer.append(myHeader);
            writeStr("\n> ");
        }
        for (int i = off; i < off + len; i++) {
            char c = cbuf[i];
            if (myColumn + 6 >= myLimit) {
                writeStr("\\\n> ");
            }
            switch(c) {
            case '\n': {
                writeStr("\n> ");
                break;
            }
            case '\r': {
                writeStr("\\r");
                break;
            }
            case '\b': {
                writeStr("\\b");
                break;
            }
            case '\t': {
                writeStr("\\t");
                break;
            }
            case '\f': {
                writeStr("\\f");
                break;
            }
            case '\\': {
                writeStr("\\\\");
                break;
            }
            default: {
                if (32 > c || 126 < c) {
                    String num = "0000" + Integer.toHexString(c);
                    int lenx = num.length();
                    num = num.substring(lenx - 4, lenx);
                    writeStr("\\u" + num);
                } else {
                    writeChars(c);
                }
            }
            }
        }
    }
}
