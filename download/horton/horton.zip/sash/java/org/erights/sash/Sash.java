// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import static org.erights.sash.Q._;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.joe_e.reflection.Deflection;
import org.joe_e.reflection.Reflection;

/**
 * Powerbox, granting the first argument initial authorities described by the
 * other arguments.
 * 
 * @see #USAGE
 * @author Mark S. Miller
 */
final class Sash {

    static private final String USAGE = 
        "Usage: java org.erights.sash.Sash <plugin-class> <auths>...\n" +
        "Where <auths> are:\n" +
        "   rw:<fname> - read/write access to file fname.\n" +
        "   ro:<fname> - read-only access to fname. Not yet implemented.\n" +
        "   q:<string> - a literal string.\n" +
        "   mp:<MagicPower> - makes the indicated magic power by calling\n" +
        "     org.erights.sash" +
        ".Magic_<MagicPower>.makeMagicPower(MagicToken.THE_ONE);\n" +
        "   <any-other-ident>:<whatever> - reserved.\n" +
        "   <anything-else> - passed as a literal string.";
    
    private 
    Sash() {}

    static Object 
    asAuth(String authDesc) throws Exception {
        int i = authDesc.indexOf(':');
        if (-1 == i) { return authDesc; }
        String left = authDesc.substring(0, i);
        String right = authDesc.substring(i+1);
        if ("ro".equals(left)) {
            throw new RuntimeException("ro not yet implemented");
        } else if ("rw".equals(left)) {
            return new File(right);
        } else if ("q".equals(left)) {
            return right;
        } else if ("mp".equals(left)) {
            Class mpClass = Class.forName("org.erights.sash.Magic_" + right);
            Method makeMagicPower = 
                Reflection.method(mpClass,
                                  "makeMagicPower",
                                  MagicToken.class);
            return Deflection.invoke(makeMagicPower,
                                     null,
                                     MagicToken.THE_ONE);
        } else {
            throw new RuntimeException("reserved: " + left);
        }
    }

    public static void 
    main(String[] args) throws Exception {
        if (args.length == 0 || "--help".equals(args[0])) {
            System.err.println(USAGE);
            return;
        }
        if ("--version".equals(args[0])) {
            System.err.println("Sash 0.1 for Joe-E ?? / ref_send 0.20");
            return;
        }
        Class clazz = Class.forName(args[0]);
        Constructor constr = Reflection.constructor(clazz);
        Plugin plugin = (Plugin)Deflection.construct(constr);
        Object[] auths = new Object[args.length-1];
        SashPowerbox powerbox = new SashPowerboxX(_,
                                                  MagicToken.THE_ONE,
                                                  clazz.getName());
        for (int i = 1; i < args.length; i++) {
            auths[i-1] = asAuth(args[i]);
        }
        plugin.start(_, powerbox, auths);
        Q.start();
    }
}
