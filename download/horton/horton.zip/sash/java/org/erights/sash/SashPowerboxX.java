// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash;

import static org.ref_send.promise.Resolved.ref;

import java.io.IOException;
import java.io.Writer;

import org.ref_send.promise.Promise;
import org.ref_send.promise.eventual.Do;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public class SashPowerboxX implements SashPowerbox {
    
    private final Eventual _;
    private final Writer myStderr;
    private final Writer myUserOut;
    private final Writer myRequestOut;
    
    public
    SashPowerboxX(Eventual _, MagicToken token, String petname) {
        MagicToken.check(token);
        this._ = _;
        myStderr = Magic_stderr.makeMagicPower(token);
        myUserOut = QuoteWriter.nest(myStderr,
                                     "Plugin " + petname + " said:");
        myRequestOut = QuoteWriter.nest(myStderr,
                                        "Plugin " + petname + " asks:");
    }

    public Promise<Writer> 
    getUserOut() {
        return ref(myUserOut);
    }

    public void 
    println(String str) throws IOException {
        myUserOut.write(str);
        myUserOut.flush();
    }

    public Promise<String> readLine() throws IOException {
        // XXX Should eventually read a line from stdin
        return ref("what me worry");
    }

    public Object 
    requestAuth(String why) throws Exception {
        myRequestOut.write(why);
        myRequestOut.flush();
        myStderr.write("? ");
        Object result = _.when(readLine(), new Do<String,Object>() {
            public Object 
            resolve(String authDesc) throws Exception {
                return Sash.asAuth(authDesc);
            }
        });
        return result;
    }
}
