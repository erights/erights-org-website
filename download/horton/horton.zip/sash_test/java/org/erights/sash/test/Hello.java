// Copyright 2007 Hewlett Packard, under the terms of the MIT X license
// found at http://www.opensource.org/licenses/mit-license.html ...............


package org.erights.sash.test;

import java.io.Writer;

import org.erights.sash.Plugin;
import org.erights.sash.SashPowerbox;
import org.ref_send.promise.eventual.Eventual;


/**
 * @author Mark S. Miller
 */
public final class Hello implements Plugin {

    public void 
    start(Eventual _,
          SashPowerbox powerbox, 
          Object... auths) throws Exception {
        powerbox.println("Hello\nworld1");
        Writer stdout = (Writer)auths[0];
        stdout.write("Hello world2\n");
        stdout.flush();
    }
}
