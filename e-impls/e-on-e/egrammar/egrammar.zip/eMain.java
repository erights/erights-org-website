import java.io.*;
import antlr.BaseAST;
import antlr.DumpASTVisitor;
import antlr.TokenStreamSelector;
import antlr.collections.AST;

class eMain {
    public static void main(String[] args) {
        try {
            //ELexer lexer = new ELexer (new DataInputStream(System.in));
            ELexer eLexer = new ELexer(new DataInputStream(new FileInputStream("example.e")));
            QuasiLexer qlexer = new QuasiLexer(eLexer.getInputState());
            TokenStreamSelector selector = new TokenStreamSelector();
            eLexer.addToSelector(selector, "e");
            qlexer.addToSelector(selector,"quasi");
            selector.select("e");
            EParser parser = new EParser(selector);
            parser.setSelector(selector);
            parser.start();
            AST results = parser.getAST();
            BaseAST.setVerboseStringConversion(true, EParser._tokenNames);
            DumpASTVisitor visitor = new DumpASTVisitor();
            visitor.visit(results);
            if (results != null) {
                System.out.println(results.toStringTree());
            }
        } catch(Exception e) {
            System.err.println("exception: "+e);
        }
    }
}