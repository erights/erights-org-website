// PrimBool.cpp:
//
//////////////////////////////////////////////////////////////////////

#include "PrimBool.h"
#include "VTable.h"

static Method *BoolMethods[] = {NULL};

Script *BoolScript = new VTable(0, BoolMethods, NULL);
