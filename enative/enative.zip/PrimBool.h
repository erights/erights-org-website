// PrimBool.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMBOOL_H)
#define PRIMBOOL_H


#include "Script.h"

extern Script *BoolScript;


#endif // !defined(PRIMBOOL_H)
