// PrimChar16.cpp:
//
//////////////////////////////////////////////////////////////////////

#include "PrimChar16.h"
#include "VTable.h"

static Method *Char16Methods[] = {NULL};

Script *Char16Script = new VTable(0, Char16Methods, NULL);
