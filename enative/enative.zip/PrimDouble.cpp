// PrimDouble.cpp:
//
//////////////////////////////////////////////////////////////////////

#include "PrimDouble.h"
#include "VTable.h"

static Method *DoubleMethods[] = {NULL};

Script *DoubleScript= new VTable(0, DoubleMethods, NULL);
