// PrimDouble.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMDOUBLE_H)
#define PRIMDOUBLE_H


#include "Script.h"

extern Script *DoubleScript;


#endif // !defined(PRIMDOUBLE_H)
