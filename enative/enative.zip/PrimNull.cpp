// PrimNull.cpp: 
//
//////////////////////////////////////////////////////////////////////

#include "PrimNull.h"
#include "VTable.h"

static Method *NullMethods[] = {NULL};

Script *NullScript = new VTable(0, NullMethods, NULL);
