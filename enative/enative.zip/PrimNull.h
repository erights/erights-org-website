// PrimNull.h: 
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMNULL_H)
#define PRIMNULL_H


#include "Script.h"

extern Script *NullScript;


#endif // !defined(PRIMNULL_H)
