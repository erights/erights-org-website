// PrimString.cpp:
//
//////////////////////////////////////////////////////////////////////

#include "PrimString.h"
#include "VTable.h"

static Method *PrimString8Methods[] = {NULL};

Script *PrimString8Script = new VTable(0, PrimString8Methods, NULL);


static Method *PrimString16Methods[] = {NULL};

Script *PrimString16Script = new VTable(0, PrimString16Methods, NULL);

