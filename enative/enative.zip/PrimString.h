// PrimString.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(PRIMSTRING_H)
#define PRIMSTRING_H


#include "Script.h"

extern Script *PrimString8Script;
extern Script *PrimString16Script;


#endif // !defined(PRIMSTRING_H)
