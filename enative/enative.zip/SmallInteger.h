// SmallInteger.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(SMALLINTEGER_H)
#define SMALLINTEGER_H


#include "Script.h"

extern Script *SmallIntegerScript;

inline bool getSmallInteger(Ref ref, int *intPtr) {
    if (ref.myScript == SmallIntegerScript) {
        *intPtr = ref.myData.word.mySmallInteger;
        return true;
    } else {
        return false;
    }
}



#endif // !defined(SMALLINTEGER_H)
