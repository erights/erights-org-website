// TextWriter.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(TEXTWRITER_H)
#define TEXTWRITER_H


#include "Script.h"

extern Ref EOut;
extern Ref EErr;


#endif // !defined(TEXTWRITER_H)
